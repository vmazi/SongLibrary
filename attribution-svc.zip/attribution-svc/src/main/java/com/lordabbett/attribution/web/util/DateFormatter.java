package com.lordabbett.attribution.web.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateFormatter {
	private static SimpleDateFormat formatyyyMMdd = new SimpleDateFormat("yyyyMMdd");
	
	public static Date getDateYyyMMdd(String yyyyMMdd ) throws ParseException {
		Date d= formatyyyMMdd.parse(yyyyMMdd);
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		return c.getTime();
		
	}
}
