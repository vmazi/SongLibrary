package com.lordabbett.attribution.base.service;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.concurrent.BasicThreadFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumerService {

	private static final Logger log = LoggerFactory.getLogger(KafkaConsumerService.class);

	private @Autowired KafkaFactory kafkaFactory;
	
	

	private @Autowired FactSetAPIService factSetApiService;
	@Value("${spring.kafka.bootstrap-servers}")
	private String bootstrapAddress;

	@Value("${config.kafka.consumer.group-id}")
	private String groupId;

	@Value("${config.kafka.consumer.enabled}")
	private boolean kafkaConsumerEnabled;

	@Value("${config.kafka.consumer.username}")
	private String consumerUsername;

	@Value("${config.kafka.consumer.password}")
	private String consumerPassword;

	@Value("${config.threads:40}")
	private int threadMultiplier;

	private int availableProcessors = Runtime.getRuntime().availableProcessors();
	private ExecutorService executorService;

	@PostConstruct
	public void initExecutorService() {
		int threads = threadMultiplier;
		log.info("Starting Executor Service With {} Threads", threads);

		
		  BasicThreadFactory threadFactory = new
		  BasicThreadFactory.Builder().namingPattern("APIThread-%d-Batch-")
		  .build();
		 
		executorService = Executors.newFixedThreadPool(threads,threadFactory);
	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {

		
		ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(kafkaFactory.createConsumerFactory(groupId, consumerUsername, consumerPassword));

		if (!kafkaConsumerEnabled)
			factory.setAutoStartup(false);

		return factory;
	}

	@KafkaListener(topics = "${config.kafka.invHoldings.topic}", containerFactory = "kafkaListenerContainerFactory")
	public void receiveOmsEvent(@Payload Map<String, Object> message) {

		message.toString();
		String enddate = (String) message.remove("Enddate");
		String startdate = (String) message.remove("Startdate");
		String document_name = (String) message.remove("Document_Name");
		String reportPeriod = (String) message.remove("ReportPeriod");
		String portfolio = (String) message.remove("Portfolio");
		String benchmark = (String) message.remove("Benchmark");
		String componentid = (String) message.remove("ComponentID");

		int attrRequestId = Integer.parseInt(((String) message.remove("AttrRequestID")));

		executorService.submit(() -> {

			System.out.println("Initiating Stream and Polling for Report");
			try {
				factSetApiService.runReport(portfolio, benchmark, startdate, enddate, reportPeriod, componentid,
						document_name, attrRequestId);

			} catch (Exception e) {
				e.printStackTrace();
			}
		});

	}

}