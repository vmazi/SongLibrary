package com.lordabbett.attribution.base.model;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;

public class ColumnComparator implements Comparator<Object> {
	int index;
	boolean asc;
	public ColumnComparator(int index,boolean asc) {
		super();
		this.index = index;
		this.asc=asc;
	}

	@Override
	public int compare(Object o1, Object o2) {

		@SuppressWarnings("unchecked")
		List<Object> list1 = (List<Object>) o1;
		@SuppressWarnings("unchecked")
		List<Object> list2 = (List<Object>) o2;

		Object listColumnElement = list1.get(index);
		int ans = 0;
		if (listColumnElement instanceof BigDecimal) {
			ans =((BigDecimal) listColumnElement).compareTo((BigDecimal) list2.get(index));
		} else if (listColumnElement instanceof Integer) {
			ans =  ((Integer) listColumnElement).compareTo((Integer) list2.get(index));
		} else if (listColumnElement instanceof String) {
			ans = ((String) listColumnElement).compareTo((String) list2.get(index));
		} 
		
		if(!asc) {
			ans = ans * -1;
		}
		return ans;

	}

}
