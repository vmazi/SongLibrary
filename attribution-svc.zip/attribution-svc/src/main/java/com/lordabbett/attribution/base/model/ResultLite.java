package com.lordabbett.attribution.base.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ResultLite extends BaseModel {
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@JsonIgnore
	private List<ColumnMetaData> columns;

	private List<List<Object>> data;

	public List<ColumnMetaData> getColumns() {
		return columns;
	}

	public void setColumns(List<ColumnMetaData> columns) {
		this.columns = columns;
	}

	@JsonProperty 
	public List<List<Object>> getData() {
		return data;
	}

	public void setData(List<List<Object>> data) {
		this.data = data;
	}

}
