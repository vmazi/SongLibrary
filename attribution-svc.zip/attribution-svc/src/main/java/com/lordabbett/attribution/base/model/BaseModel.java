package com.lordabbett.attribution.base.model;

import java.io.Serializable;

public class BaseModel implements Serializable{

	private String zipFormat;
	private String datasetName;
	
	public void setZipFormat(String zipFormat) {
		this.zipFormat = zipFormat;
	}
	public String getZipFormat() {
		return this.zipFormat;
	}
	public String getDatasetName() {
		return datasetName;
	}
	public void setDatasetName(String datasetName) {
		this.datasetName = datasetName;
	}
	private static final long serialVersionUID = 7086076307201314382L;

}
