package com.lordabbett.attribution.web.config;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lordabbett.attribution.base.model.DataServiceException;


@ControllerAdvice
@RequestMapping(produces = "application/vnd.error+json")
public class ExceptionControllerAdvice {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionControllerAdvice.class);
	
	private ResponseEntity<DataServiceException> error(final Exception exception, final HttpStatus httpStatus,
			final String logRef) {
		final String message = Optional.of(exception.getMessage()).orElse(exception.getClass().getSimpleName());
		
		LOGGER.error("failed to execute ", exception);
		return new ResponseEntity<>(new DataServiceException(message, httpStatus.value(),null), httpStatus);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<DataServiceException> assertionException(final Exception e) {
		return error(e, HttpStatus.INTERNAL_SERVER_ERROR, e.getLocalizedMessage());
	}

	@ExceptionHandler(Throwable.class)
	public ResponseEntity<DataServiceException> assertionException(final Throwable e) {
		return error(new Exception(e), HttpStatus.INTERNAL_SERVER_ERROR, e.getLocalizedMessage());
	}
}
