package com.lordabbett.attribution.web.util;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lordabbett.attribution.base.model.BaseModel;
import com.lordabbett.attribution.base.model.ColumnMetaData;
import com.lordabbett.attribution.base.model.DataServiceException;
import com.lordabbett.attribution.base.model.InfoModel;
import com.lordabbett.attribution.base.model.ResultLite;



public class JsonHttpMessageConverterLite extends AbstractHttpMessageConverter<BaseModel> {

	private static final Logger LOGGER = LoggerFactory.getLogger(JsonHttpMessageConverterLite.class);
	public JsonHttpMessageConverterLite() {
		super(new MediaType("application", "json"));
	}

	@Override
	protected boolean supports(Class<?> clazz) {
		return BaseModel.class.isAssignableFrom(clazz);
	}

	@Override
	protected BaseModel readInternal(Class<? extends BaseModel> clazz, HttpInputMessage inputMessage)
			throws IOException, HttpMessageNotReadableException {
		
		return null;
	}

	@Override
	protected void writeInternal(BaseModel object, HttpOutputMessage outputMessage)
			throws IOException, HttpMessageNotWritableException {
		
		if(DataServiceException.class.isAssignableFrom(object.getClass())) {
			outputMessage.getHeaders().set(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);
			OutputStream outputStream = outputMessage.getBody();
			DataServiceException exception = (DataServiceException) object;
			outputStream.write(String.valueOf(exception.getMessage()).getBytes());
			outputStream.close();
			return;
		}
		if(object.getZipFormat()!=null&&object.getZipFormat().contains(".gz")) {
			GzHttpMessageConverter gzmess = new GzHttpMessageConverter();
			gzmess.writeInternal(object, outputMessage);
			gzmess = null;
			return;
		}

		try {
			if(object instanceof InfoModel) {
				outputMessage.getHeaders().set(HttpHeaders.CONTENT_TYPE, "application/json");
				OutputStream outputStream = outputMessage.getBody();
				String str = ((InfoModel) object).getMessage();
				outputStream.write(str.getBytes());
				outputStream.flush();
				outputStream.close();
				return;
			}
			ResultLite result = (ResultLite) object;
			OutputStream outputStream = outputMessage.getBody();
			List<ColumnMetaData> columns= result.getColumns();
			
			ObjectMapper mapper = new ObjectMapper();

			boolean noStreaming = true;
			if(noStreaming) {
				List<Map<String, Object>> resultList = new ArrayList<>();
				for(List<Object> row : result.getData()) {
					SortedMap<String, Object> rowMap = new TreeMap<>();
					for(int i = 0; i < columns.size(); ++i) {
						rowMap.put(columns.get(i).getName(), row.get(i));
					}
					
					resultList.add(rowMap);
					outputStream.flush();				
				}
				byte[] resultInBytes = mapper.writeValueAsBytes(resultList);
				LOGGER.info("sending json to client");
				outputStream.write("{\"data\": ".getBytes());
				outputStream.write(resultInBytes);
				outputStream.write("}".getBytes());
				outputStream.close();
				LOGGER.info("request completed successfully");
				return;
				
			} else {
				List<String> resultStringList = new ArrayList<>();
	
				Map<String, Object> rowMap = new HashMap<>();
				for(List<Object> row : result.getData()) {
					for(int i = 0; i < columns.size(); ++i) {
						rowMap.put(columns.get(i).getName(), row.get(i));
					}
	
					resultStringList.add(mapper.writeValueAsString(rowMap));
					//added this to reduce memory print
					rowMap.clear();
					row.clear();
				}
				result = null;
				LOGGER.info("sending json to client");
				//outputStream.write("{\"data\": ".getBytes());
				outputStream.write(String.valueOf(resultStringList).getBytes());
				//outputStream.write("}".getBytes());
				outputStream.flush();
				outputStream.close();
				LOGGER.info("request completed successfully");
				return;
			}
 		} catch (Exception e) {
			LOGGER.error("failed to write in csv format", e);
		}


	}

	
}
