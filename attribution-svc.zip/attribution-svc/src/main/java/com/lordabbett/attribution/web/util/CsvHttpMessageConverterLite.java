package com.lordabbett.attribution.web.util;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;

import com.fasterxml.jackson.databind.SequenceWriter;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.lordabbett.attribution.base.model.BaseModel;
import com.lordabbett.attribution.base.model.ColumnMetaData;
import com.lordabbett.attribution.base.model.DataServiceException;
import com.lordabbett.attribution.base.model.InfoModel;
import com.lordabbett.attribution.base.model.ResultLite;


public class CsvHttpMessageConverterLite extends AbstractHttpMessageConverter<BaseModel> {

	private static final Logger LOGGER = LoggerFactory.getLogger(CsvHttpMessageConverterLite.class);

	public CsvHttpMessageConverterLite() {
		super(new MediaType("text", "csv"));
	}

	@Override
	protected boolean supports(Class<?> clazz) {
		return BaseModel.class.isAssignableFrom(clazz);
	}

	@Override
	protected ResultLite readInternal(Class<? extends BaseModel> clazz, HttpInputMessage inputMessage)
			throws IOException, HttpMessageNotReadableException {

		return null;
	}

	@Override
	protected void writeInternal(BaseModel object, HttpOutputMessage outputMessage)
			throws IOException, HttpMessageNotWritableException {
		try {

			if (DataServiceException.class.isAssignableFrom(object.getClass())) {
				outputMessage.getHeaders().set(HttpHeaders.CONTENT_DISPOSITION, "inline");
				outputMessage.getHeaders().set(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);
				OutputStream outputStream = outputMessage.getBody();
				DataServiceException exception = (DataServiceException) object;
				outputStream.write(String.valueOf(exception.getMessage()).getBytes());
				outputStream.close();
				return;
			}
			if (object.getZipFormat()!=null&&object.getZipFormat().contains(".gz")) {
				GzHttpMessageConverter gzmess = new GzHttpMessageConverter();
				gzmess.writeInternal(object, outputMessage);
				gzmess = null;
				return;
			}
			else if(object instanceof InfoModel) {
				outputMessage.getHeaders().setContentDispositionFormData("attachment", "info.csv");
				outputMessage.getHeaders().setContentType(new MediaType("text","csv"));
				OutputStream outputStream = outputMessage.getBody();
				outputStream.write(((InfoModel)object).getMessage().getBytes());
				outputStream.close();
				return;
			}
			outputMessage.getHeaders().setContentDispositionFormData("attachment", object.getDatasetName()+".csv");

			LOGGER.info("Streaming started");
			ResultLite result = (ResultLite) object;
			OutputStream outputStream = outputMessage.getBody();
			List<List<Object>> listOfMap = result.getData();
			List<ColumnMetaData> columns = result.getColumns();

			CsvSchema schema = null;
			CsvSchema.Builder schemaBuilder = CsvSchema.builder();
			if (columns != null && !columns.isEmpty()) {
				for (ColumnMetaData col : columns) {
					schemaBuilder.addColumn(col.getName());
				}
				schema = schemaBuilder.build().withLineSeparator("\r\n").withHeader();
			}
			CsvMapper mapper = new CsvMapper();
			SequenceWriter writer = mapper.writer(schema).writeValues(outputStream);
			int i = 0;
			for (List<Object> list : listOfMap) {
				writer.write(list);
				list.clear();
				if (i++ % 5000 == 0) {
					outputStream.flush();
				}
			}
			outputStream.close();
		} catch (Exception e) {
			LOGGER.error("failed to write in csv format", e);
		}
		LOGGER.info("request completed successfully");
	}

}
