package com.lordabbett.attribution.base.service;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;



@Service
public class KafkaService {

	private @Autowired KafkaFactory kafkaFactory;
	private @Value("${config.kafkaRequestTimeout}") int kafkaRequestTimeout;
	private @Value("${config.kafkaEnabled}") boolean kafkaEnabled;
	private @Value("${config.kafka.topic}") String invHoldingsTopic;
	private @Value("${config.kafka.clientId}") String clientId;
	private @Value("${config.kafka.producer.username}") String producerUsername;
	private @Value("${config.kafka.producer.password}") String producerPassword;

	private KafkaTemplate<String, Map<String, String>> kafkaTemplate;

	@PostConstruct
	private void init() {
		kafkaTemplate = kafkaTemplate();
	}

	public KafkaTemplate<String, Map<String, String>> kafkaTemplate() {
		if (!kafkaEnabled)
			return null;

		return new KafkaTemplate<>(kafkaFactory.createProducerFactory(clientId, producerUsername, producerPassword));
	}

	public void sendMessage(Map<String, String> payload) {
		kafkaTemplate.send(invHoldingsTopic, payload);
	}

}
