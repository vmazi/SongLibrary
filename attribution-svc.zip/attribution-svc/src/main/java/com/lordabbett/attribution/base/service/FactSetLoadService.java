package com.lordabbett.attribution.base.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.concurrent.BasicThreadFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.lordabbett.attribution.base.dao.BaseDAO;
import com.lordabbett.attribution.base.model.ResultLite;

@Service
public class FactSetLoadService {

	@Autowired
	private BaseDAO baseDAO;

	protected JdbcTemplate idaJdbcTemplate;

	private ArrayList<Integer> emports;

	private ArrayList<Integer> hyports;
	private static final Logger LOGGER = LoggerFactory.getLogger(FactSetLoadService.class);

	@Autowired
	BaseService baseService;

	public FactSetLoadService(@Qualifier("idaJdbcTemplate") JdbcTemplate idaJdbcTemplate) {

		this.idaJdbcTemplate = idaJdbcTemplate;
	}

	@PostConstruct
	public void initFactSetLoadService() {
		try {
			this.hyports = listOfAccountsbyRunType("FS_HY_HLDG");
			this.emports = listOfAccountsbyRunType("FS_EM_HLDG");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected String[] getPortBenchStrings(String dirFile) throws Exception {

		File preproc = new File(dirFile);

		String portvbench;
		BufferedReader br = new BufferedReader(new FileReader(preproc));
		portvbench = br.readLine();
		br.close();
		String[] splitArray = portvbench.split(" vs. ");

		splitArray[1] = splitArray[1].split(";")[0];
		return splitArray;
	}

	protected String[] getPortStrings(String dirFile) throws Exception {

		File preproc = new File(dirFile);

		String portvbench;
		BufferedReader br = new BufferedReader(new FileReader(preproc));
		portvbench = br.readLine();
		br.close();
		String[] splitArray = portvbench.split(";");

		return splitArray;
	}

	protected String getDateString(String date) throws Exception {
		DateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
		Date result = df.parse(date);

		DateFormat df2 = new SimpleDateFormat("yyyMMdd", Locale.ENGLISH);
		String datout = df2.format(result);

		return datout;

	}

	protected String[] getStartAndEndDates(String filename) throws Exception {

		String dateline = null;
		BufferedReader br = new BufferedReader(new FileReader(filename));
		for (int i = 0; i < 6; i++) {
			dateline = br.readLine();
		}

		String[] dates = dateline.split(" to ");

		if (dates.length > 1) {
			dates[1] = dates[1].split(";")[0];

			dates[0] = getDateString(dates[0]);
			dates[1] = getDateString(dates[1]);
		} else {
			dates[0] = dates[0].split(";")[0];
			dates[0] = getDateString(dates[0]);
		}
		br.close();
		return dates;
	}

	protected int generateReportInstance(String filename, int repDefID, String repPeriod, boolean inactivate)
			throws Exception {
		int pid;
		int bid;

		String[] portBenchString = getPortBenchStrings(filename);

		pid = lookupPort(portBenchString[0]);

		bid = lookupBench(portBenchString[1]);

		String[] dates = getStartAndEndDates(filename);

		if (filename.toLowerCase().contains("mtd")) {
			repPeriod = "mtd";
		}

		ResultLite repinst = insertIntoReportInstanceTable(pid, bid, dates[0], dates[1], repDefID, 1, repPeriod,
				inactivate);
		int repInstID = ((BigDecimal) repinst.getData().get(0).get(0)).intValue();
		return repInstID;
	}

	/**
	 * Gets Portfolio ID from portfolios lookup view
	 * 
	 * @param params
	 * @param monthRep
	 * @return
	 * @throws Exception
	 */
	public int lookupPort(String portfolio) throws Exception {
		Map<String, Object> params = new ConcurrentHashMap<String, Object>();
		int pid;
		LOGGER.info("portfolio for this sheet: " + portfolio);
		String pidSql = "select PortfolioID, Symbol, Description from IDAP.lookup.PortfoliosVW where Symbol = '"
				+ portfolio + "'";

		ResultLite portResult = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, pidSql, null, true);

		if (portResult.getData().size() > 0) {
			pid = ((BigDecimal) portResult.getData().get(0).get(0)).intValue();
		} else {
			throw new Exception("Portfolio not found");
		}
		return pid;
	}

	/**
	 * Gets Portfolio ID from portfolios lookup view
	 * 
	 * @param params
	 * @param monthRep
	 * @return
	 * @throws Exception
	 */
	private int lookupBench(String portfolio) throws Exception {
		Map<String, Object> params = new ConcurrentHashMap<String, Object>();
		Map<String, String> portBenchMappings = getPortBenchMappings();

		if (portBenchMappings.containsKey(portfolio)) {
			portfolio = portBenchMappings.get(portfolio);
		}

		int pid;

		LOGGER.info("Benchmark for this sheet: " + portfolio);

		String pidSql = "Select " + "   P2.PortfolioID, P2.Symbol " + "From  " + "    IDAP.lookup.PortfoliosVW P "
				+ "Inner Join " + "    IDAP.dbo.PORTFOLIO_RELATION R " + "    On "
				+ "        P.PortfolioID = R.PORTFOLIO_ID " + "Inner Join " + "    IDAP.lookup.PortfoliosVW P2 "
				+ "    On " + "        R.RELATED_PORTFOLIO_ID = P2.PortfolioID "
				+ "        And P2.FACTSET_ATTRIBUTION = 'Y'  " + "        And P2.PortfolioType = 'INDEX' "
				+ "Inner Join " + "    IDAP.dbo.PORTFOLIO_RELATION_DESC RD " + "    On "
				+ "        R.PORTFOLIO_RELATION_ID = RD.PORTFOLIO_RELATION_ID "
				+ "        And RD.RELATION_TYPE = 'SubSet' " + "Where P.PortfolioType = 'VIRTUAL' and P.Symbol ='"
				+ portfolio + "'";

		ResultLite portResult = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, pidSql, null, true);

		if (portResult.getData().size() > 0) {
			pid = ((BigDecimal) portResult.getData().get(0).get(0)).intValue();
			return pid;
		}

		else {
			pidSql = "select PortfolioID, Symbol, Description from IDAP.lookup.PortfoliosVW where Symbol = '"
					+ portfolio + "'";

			portResult = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, pidSql, null, true);

			if (portResult.getData().size() > 0) {
				pid = ((BigDecimal) portResult.getData().get(0).get(0)).intValue();
				return pid;
			}

		}

		throw new Exception("Benchark not found: " + portfolio);
	}

	private ConcurrentHashMap<String, String> getPortBenchMappings() {
		ConcurrentHashMap<String, String> Mapping = new ConcurrentHashMap<String, String>();
		Mapping.put("MLHUC0", "HUCO");
		return Mapping;
	}

	public int getActiveReportFromFile(String filename, int repDefID, String repPeriod) throws Exception {
		int pid;
		int bid;

		String[] portBenchString = getPortBenchStrings(filename);

		pid = lookupPort(portBenchString[0]);

		bid = lookupBench(portBenchString[1]);

		String[] dates = getStartAndEndDates(filename);

		if (filename.toLowerCase().contains("mtd")) {
			repPeriod = "mtd";
		}

		return getActiveReport(repDefID, pid, bid, dates[1], dates[0], 1, repPeriod);

	}

	private int getActiveReport(int repDefID, int ppid, int pbid, String end, String start, int sourceID,
			String repPeriod) throws Exception {
		String inactivateSql = "Declare @ROWCNT int;select ID from reporting.dbo.report_instance where REPORT_DEFINITION_ID = :repDefID and "
				+ "PORTFOLIO_ID = :ppid and " + "BENCHMARK_ID = :pbid and " + "ASOFDATE = :asofdate and "
				+ "SOURCE_ID = :sourceID and " + "IS_REPORT_ACTIVE = 1 and  "
				+ "REPORT_PARAM1_NAME = 'reportPeriod' and " + "REPORT_PARAM1_VALUE = :repPeriod;";

		Map<String, Object> params2 = new ConcurrentHashMap<String, Object>();
		params2.put("repDefID", Integer.toString(repDefID));
		params2.put("ppid", Integer.toString(ppid));
		params2.put("pbid", Integer.toString(pbid));
		params2.put("asofdate", end);
		params2.put("sourceID", Integer.toString(sourceID));
		params2.put("repPeriod", repPeriod);

		ResultLite ans = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params2, inactivateSql, null, true);
		if (ans.getData().size() > 0) {
			int repInstID = ((Integer) ans.getData().get(0).get(0)).intValue();
			return repInstID;
		} else {
			return -1;
		}

	}

	public void activateReport(int reportInstanceId) throws Exception {
		String inactivateSql = "Declare @ROWCNT int;update reporting.dbo.report_instance set IS_REPORT_ACTIVE = 1 where ID =:reportInstanceId ;Select @ROWCNT = @@ROWCOUNT; Select @ROWCNT;";

		Map<String, Object> params2 = new ConcurrentHashMap<String, Object>();
		params2.put("reportInstanceId", Integer.toString(reportInstanceId));

		ResultLite ans = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params2, inactivateSql, null, true);
		if ((Integer) ans.getData().get(0).get(0) > 0) {
			LOGGER.info("activating report with: " + params2);

		}
	}

	public void inActivateReport(int reportInstanceId) throws Exception {
		String inactivateSql = "Declare @ROWCNT int;update reporting.dbo.report_instance set IS_REPORT_ACTIVE = 0 where ID =:reportInstanceId ;Select @ROWCNT = @@ROWCOUNT; Select @ROWCNT;";

		Map<String, Object> params2 = new ConcurrentHashMap<String, Object>();
		params2.put("reportInstanceId", Integer.toString(reportInstanceId));

		ResultLite ans = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params2, inactivateSql, null, true);
		if ((Integer) ans.getData().get(0).get(0) > 0) {
			LOGGER.info("deactivating report with: " + params2);

		}
	}

	private ResultLite insertIntoReportInstanceTable(int ppid, int pbid, String start, String end, int repDefID,
			int sourceID, String repPeriod, boolean inactivate) throws Exception {

		// inactivateReport(repDefID, ppid, pbid, end, start, sourceID, repPeriod);

		Map<String, Object> params = new ConcurrentHashMap<String, Object>();
		String insRepInst = "insert into reporting.dbo.report_instance (REPORT_DEFINITION_ID,PORTFOLIO_ID,BENCHMARK_ID,ASOFDATE,STARTDATE,ENDDATE,SOURCE_ID,CREATED_BY,"
				+ "IS_REPORT_ACTIVE,REPORT_PARAM1_NAME,REPORT_PARAM1_VALUE) values ( " + repDefID + ", " + ppid + ", "
				+ pbid + ", '" + end + "', '" + start + "', '" + end + "'," + sourceID
				+ ", 'vkurkal',0,'reportPeriod','" + repPeriod + "');";
		insRepInst = insRepInst + "SELECT SCOPE_IDENTITY();";

		return (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, insRepInst, null, true);

	}

	private String getFactSetTagGroupNameFromRepDef(int repDefID) throws Exception {
		String getRepDefName = "select name from reporting.dbo.report_definition where report_definition_id ="
				+ repDefID;

		Map<String, Object> params = new ConcurrentHashMap<String, Object>();
		ResultLite tagGroupAns = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefName, null, true);

		return (String) tagGroupAns.getData().get(0).get(0);
	}

	private int insertTagGroupingInstanceWithNOParent(int repInstID, String displayName, String tagName, int repDefID)
			throws Exception {
		Map<String, Object> params = new ConcurrentHashMap<String, Object>();

		String tagGroupName = getFactSetTagGroupNameFromRepDef(repDefID);

		String grandTotalSql = "DECLARE @TAGID int;DECLARE @TAGGROUP int; DECLARE @TAGMAP int;"
				+ "SET @TAGID = (SELECT TAG_ID from reporting.dbo.TAG where name = :tagName );"
				+ "SET @TAGGROUP = (select tag_grouping_id from reporting.dbo.tag_grouping where tag_grouping_name = '"
				+ tagGroupName + "');"
				+ "SET @TAGMAP = (select ID from reporting.dbo.tag_grouping_map where tag_grouping_id = @TAGGROUP and tag_id = @TAGID);"
				+ "INSERT into reporting.dbo.tag_grouping_instance (tag_grouping_map_id, data,created_by,report_instance_id) values (@TAGMAP,:displayName,'vkurkal',:repInstID);"
				+ "SELECT SCOPE_IDENTITY();";

		params.put("repInstID", Integer.toString(repInstID));

		params.put("displayName", displayName);

		params.put("tagName", tagName);
		ResultLite rowins1 = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, grandTotalSql, null, true);

		int taggrp = ((BigDecimal) rowins1.getData().get(0).get(0)).intValue();
		return taggrp;
	}

	private int getParentTagGroupingInstanceIdFromTree(String data, int repInstID, int repDefID, int seqno,
			ArrayList<Object[]> tagTree) throws Exception {
		int parent = -1;
		Object[] treeinput;
		String[] tree = data.split(">>");

		for (int i = 0; i < tree.length - 1; i++) {
			if (i < tagTree.size() && tree[i].equals((String) tagTree.get(i)[0])) {
				parent = (int) tagTree.get(i)[1];
			} else {
				tagTree.clear();
				parent = -1;
				break;
			}

		}

		if (parent == -1) {
			String parentSql = "select id from reporting.dbo.tag_grouping_instance tgi where tgi.REPORT_INSTANCE_ID = :repinst "
					+ "and data = :data COLLATE SQL_Latin1_General_CP1_CS_AS order by CREATED_DTTM desc";
			ConcurrentHashMap<String, Object> params = new ConcurrentHashMap<String, Object>();
			params.put("repinst", Integer.toString(repInstID));
			params.put("data", tree[0]);

			ResultLite ans = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, parentSql, null, true);

			parent = Integer.parseInt((String) ans.getData().get(0).get(0));
			treeinput = new Object[2];
			treeinput[0] = tree[0];
			treeinput[1] = parent;

			tagTree.add(treeinput);
			for (int i = 1; i < (tree.length - 1); i++) {
				if ((!tree[i].equals("NONE")) || (tree[i].equals("NONE") && tree[0].equals("Bank Loan"))) {
					String childSql = "select id from reporting.dbo.tag_grouping_instance tgi where tgi.REPORT_INSTANCE_ID = :repinst "
							+ "and data = :data and parent_id = :parent";
					ConcurrentHashMap<String, Object> params2 = new ConcurrentHashMap<String, Object>();
					params2.put("repinst", Integer.toString(repInstID));
					params2.put("data", tree[i]);
					params2.put("parent", Integer.toString(parent));
					ResultLite ans2 = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params2, childSql, null, true);
					if (ans2.getData().size() != 0) {

						parent = Integer.parseInt((String) ans2.getData().get(0).get(0));
						treeinput = new Object[2];
						treeinput[0] = tree[i];
						treeinput[1] = parent;

						tagTree.add(treeinput);
					}
				}
			}
		}

		return parent;

	}

	private int insertTagGroupingInstanceWithParent(int repInstID, String displayName, String tagName, int repDefID,
			int parentId) throws Exception {
		Map<String, Object> params = new ConcurrentHashMap<String, Object>();

		String tagGroupName = getFactSetTagGroupNameFromRepDef(repDefID);

		String grandTotalSql = "DECLARE @TAGID int;DECLARE @TAGGROUP int; DECLARE @TAGMAP int;"
				+ "SET @TAGID = (SELECT TAG_ID from reporting.dbo.TAG where name = :tagName COLLATE SQL_Latin1_General_CP1_CS_AS );"
				+ "SET @TAGGROUP = (select tag_grouping_id from reporting.dbo.tag_grouping where tag_grouping_name = '"
				+ tagGroupName + "');"
				+ "SET @TAGMAP = (select ID from reporting.dbo.tag_grouping_map where tag_grouping_id = @TAGGROUP and tag_id = @TAGID);"
				+ "INSERT into reporting.dbo.tag_grouping_instance (tag_grouping_map_id, data,created_by,report_instance_id,parent_id) values (@TAGMAP,:displayName,'vkurkal',:repInstID,:parentID);"
				+ "SELECT SCOPE_IDENTITY();";

		params.put("repInstID", Integer.toString(repInstID));
		params.put("parentID", Integer.toString(parentId));
		params.put("displayName", displayName);

		params.put("tagName", tagName);
		ResultLite rowins1 = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, grandTotalSql, null, true);

		int taggrp = ((BigDecimal) rowins1.getData().get(0).get(0)).intValue();
		return taggrp;
	}

	private void loadReportRowIntoDB(String line, int reportInstID, int repDefID, Map<String, Object> analytids,
			int seqno, Map<String, Object> repDefIds, int pid, ArrayList<Object[]> tagTree, ArrayList<Integer> hyports)
			throws Exception {

		int taggrpinst;
		String[] tags = null;
		int parentid;
		if (line.contains(">>")) {
			tags = line.split(">>");
			tags[tags.length - 1] = tags[tags.length - 1].split(";")[0];

			parentid = getParentTagGroupingInstanceIdFromTree(line.split(";")[0], reportInstID, repDefID, seqno,
					tagTree);

			taggrpinst = insertTagGroupingInstanceWithParent(reportInstID, tags[tags.length - 1], "Security", repDefID,
					parentid);

			String insertSql = "INSERT INTO reporting.[dbo].[REPORT_ROW_INSTANCE]([REPORT_INSTANCE_ID], [TAG_GROUPING_INSTANCE_ID], [SEQ_NO], [CREATED_BY] ) "
					+ "VALUES( " + reportInstID + "  ," + taggrpinst + "," + seqno
					+ ", 'vkurkal'); SELECT SCOPE_IDENTITY();";
			Map<String, Object> params = new ConcurrentHashMap<String, Object>();

			ResultLite rowins = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, insertSql, null, true);
			int totalsRow = ((BigDecimal) rowins.getData().get(0).get(0)).intValue();

			ArrayList<String> totals = new ArrayList<String>(Arrays.asList(line.split(";")));

			loadReportTotalsIntoDB(totals, totalsRow, analytids, repDefID, repDefIds, pid, hyports);
		}

	}

	private void loadTotalRowIntoDB(int reportInstID, String line, int repDefID, int grandTotalTagID,
			Map<String, Object> analytids, int seqno, Map<String, Object> repDefIds, int pid,
			ArrayList<Integer> hyports) throws Exception {
		String[] tags = line.split(";");

		if (tags.length > 0) {
			int taggrpinst = insertTagGroupingInstanceWithParent(reportInstID, tags[0], "Security", repDefID,
					grandTotalTagID);

			String insertSql = "INSERT INTO reporting.[dbo].[REPORT_ROW_INSTANCE]([REPORT_INSTANCE_ID], [TAG_GROUPING_INSTANCE_ID], [SEQ_NO], [CREATED_BY] ) "
					+ "VALUES( " + reportInstID + "  ," + taggrpinst + "," + seqno
					+ ", 'vkurkal'); SELECT SCOPE_IDENTITY();";
			Map<String, Object> params = new ConcurrentHashMap<String, Object>();

			ResultLite rowins = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, insertSql, null, true);
			int totalsRow = ((BigDecimal) rowins.getData().get(0).get(0)).intValue();

			ArrayList<String> totals = new ArrayList<String>(Arrays.asList(line.split(";")));

			loadReportTotalsIntoDB(totals, totalsRow, analytids, repDefID, repDefIds, pid, hyports);
		}
	}

	public void loadFactsetReturns(String dirFile, String repPeriod, ArrayList<Integer> hyports) throws Exception {
		String line = null;
		int pid, bid;
		String[] dates = getStartAndEndDates(dirFile);

		String[] portBenchString = getPortBenchStrings(dirFile);

		pid = lookupPort(portBenchString[0]);

		bid = lookupBench(portBenchString[1]);

		BufferedReader br = new BufferedReader(new FileReader(dirFile));
		for (int i = 0; i < 9; i++) {
			line = br.readLine();
		}
		line = br.readLine();

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String asatdate = dateFormat.format(date);

		Map<String, Object> params = new ConcurrentHashMap<String, Object>();
		StringBuilder batchInsert = new StringBuilder();
		while ((line = br.readLine()) != null) {
			if (!line.contains(";;;;;;;;;;;;")) {
				Integer currentPort = new Integer(pid);
				if (hyports.contains(currentPort)) {
					batchInsert.append(insertHYReturns(line, dates[1], params, asatdate, repPeriod, pid, bid));

				} else {
					batchInsert.append(insertReturns(line, dates[1], params, asatdate, repPeriod, pid, bid));
				}

				batchInsert.append("Select SCOPE_IDENTITY();");
				try {
					baseDAO.findUsingSQL(idaJdbcTemplate, params, batchInsert.toString(), null, true);
				} catch (Exception e) {

					e.printStackTrace();
					br.close();
					StringWriter sw = new StringWriter();
					PrintWriter pw = new PrintWriter(sw);
					e.printStackTrace(pw);

					baseService.emailReportListLoaded(sw.toString());
					throw (e);
				}
				params.clear();
				batchInsert.setLength(0);
			} else {

				break;
			}
		}
		br.close();
	}

	public void loadFactsetAnalytics(String dirFile) throws Exception {
		String line = null;
		int pid;
		String[] dates = getStartAndEndDates(dirFile);

		String[] portBenchString = getPortStrings(dirFile);

		pid = lookupPort(portBenchString[0]);

		BufferedReader br = new BufferedReader(new FileReader(dirFile));
		for (int i = 0; i < 9; i++) {
			line = br.readLine();
		}
		line = br.readLine();

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String asatdate = dateFormat.format(date);
		StringBuilder batchInsert = new StringBuilder();
		Map<String, Object> params = new ConcurrentHashMap<String, Object>();

		batchInsert.append(insertAnalytics(line, dates[0], params, asatdate, pid));
		batchInsert.append("Select SCOPE_IDENTITY();");
		try {
			baseDAO.findUsingSQL(idaJdbcTemplate, params, batchInsert.toString(), null, true);
		} catch (Exception e) {

			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);

			baseService.emailReportListLoaded(sw.toString());
			throw (e);
		}
		params.clear();
		batchInsert.setLength(0);
		line = br.readLine();

		while ((line = br.readLine()) != null) {
			if (!line.contains(";;;;;;;;;;;;")) {
				batchInsert.append(insertAnalytics(line, dates[0], params, asatdate, pid));
				batchInsert.append("Select SCOPE_IDENTITY();");
				try {
					baseDAO.findUsingSQL(idaJdbcTemplate, params, batchInsert.toString(), null, true);
				} catch (Exception e) {

					StringWriter sw = new StringWriter();
					PrintWriter pw = new PrintWriter(sw);
					e.printStackTrace(pw);

					baseService.emailReportListLoaded(sw.toString());
					throw (e);
				}
				params.clear();
				batchInsert.setLength(0);
			} else {
				break;
			}
		}
		br.close();
	}

	public String insertAnalytics(String line, String date, Map<String, Object> params, String asatdate, int pid) {

		ArrayList<String> totals = new ArrayList<String>(Arrays.asList(line.split(";")));

		String sql2 = "INSERT INTO [STAGING].[FactSet].[ANALYTIC]" + "(" + "[ASOFDATE]" + ",[PORTFOLIO_ID]"
				+ ",[SYMBOL]" + ",[SECURITY_NAME]" + ",[AVG_LIFE]" + ",[YTM]" + ",[OAS]"
				+ ",[PORT_ENDING_EFFECTIVE_DURATION]" + ",[PORT_ENDING_MODIFIED_DURATION]"
				+ ",[PORT_ENDING_SPREAD_DURATION]" + ",[PORT_ENDING_PARTIAL_DUR_1MNTH]"
				+ ",[PORT_ENDING_PARTIAL_DUR_3MNTH]" + ",[PORT_ENDING_PARTIAL_DUR_6MNTH]"
				+ ",[PORT_ENDING_PARTIAL_DUR_1YR]" + ",[PORT_ENDING_PARTIAL_DUR_2YR]" + ",[PORT_ENDING_PARTIAL_DUR_3YR]"
				+ ",[PORT_ENDING_PARTIAL_DUR_4YR]" + ",[PORT_ENDING_PARTIAL_DUR_5YR]" + ",[PORT_ENDING_PARTIAL_DUR_6YR]"
				+ ",[PORT_ENDING_PARTIAL_DUR_7YR]" + ",[PORT_ENDING_PARTIAL_DUR_8YR]" + ",[PORT_ENDING_PARTIAL_DUR_9YR]"
				+ ",[PORT_ENDING_PARTIAL_DUR_10YR]" + ",[PORT_ENDING_PARTIAL_DUR_15YR]"
				+ ",[PORT_ENDING_PARTIAL_DUR_20YR]" + ",[PORT_ENDING_PARTIAL_DUR_25YR]"
				+ ",[PORT_ENDING_PARTIAL_DUR_30YR]" + ",[PORT_ENDING_PARTIAL_DUR_TOTAL]"
				+ ",[PORT_ENDING_YIELD_TO_WORST]" + ",[CREATEDDTTM]" + ",[ASATDATE])" + "VALUES('" + date + "'," + pid
				+ ",:total0" + ",:total1,"
				+ (totals.get(2).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total2))") + ","
				+ (totals.get(3).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total3))") + ","
				+ (totals.get(4).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total4))") + ","
				+ (totals.get(5).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total5))") + ","
				+ (totals.get(6).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total6))") + ","
				+ (totals.get(7).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total7))") + ","
				+ (totals.get(8).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total8))") + ","
				+ (totals.get(9).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total9))") + ","
				+ (totals.get(10).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total10))") + ","
				+ (totals.get(11).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total11))") + ","
				+ (totals.get(12).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total12))") + ","
				+ (totals.get(13).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total13))") + ","
				+ (totals.get(14).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total14))") + ","
				+ (totals.get(15).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total15))") + ","
				+ (totals.get(16).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total16))") + ","
				+ (totals.get(17).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total17))") + ","
				+ (totals.get(18).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total18))") + ","
				+ (totals.get(19).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total19))") + ","
				+ (totals.get(20).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total20))") + ","
				+ (totals.get(21).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total21))") + ","
				+ (totals.get(22).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total22))") + ","
				+ (totals.get(23).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total23))") + ","
				+ (totals.get(24).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total24))") + ","
				+ (totals.get(25).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total25))") + ","
				+ (totals.get(26).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total26))") + ","
				+ "getDate(),'" + asatdate + "');";

		for (int i = 0; i < totals.size(); i++) {
			if (totals.get(i).equals("--")) {
			} else {
				params.put("total" + i, totals.get(i));
			}
		}

		if (params.containsKey("total0")) {
			String total0 = (String) params.remove("total0");
			total0 = total0.split(">>")[total0.split(">>").length - 1];
			params.put("total0", total0);
		} else {
			params.put("total0", "NULL");
		}
		return sql2;

	}

	public String insertHYReturns(String line, String date, Map<String, Object> params, String asatdate,
			String repPeriod, int pid, int bid) {

		ArrayList<String> totals = new ArrayList<String>(Arrays.asList(line.split(";")));

		String sql = "INSERT INTO [ATTR].[FACTSET].[SECURITY_RETURN] "
				+ "([ASOFDATE],[ASATDATE] ,[PORTFOLIO_ID]  ,[BENCHMARK_ID] ,[REPORT_PERIOD],[SECURITY_NAME],"
				+ "[SECURITY_ID],[ANALYST_NAME]"
				+ ",[PORT_PRICE_RTN],[PORT_FIXED_INCOME_COUPON_RTN],[ML_RTG],[VARIATION_IN_AVG_WEIGHT]"
				+ ",[PORT_AVG_WEIGHT],[PORT_TOTAL_RTN],[PORT_CONTRIB_TO_RTN],[BENCH_AVG_WEIGHT],[BENCH_TOTAL_RTN]"
				+ ",[BENCH_CONTRIB_TO_RETURN],[ALLOCATION_EFFECT],[SELECTION_EFFECT],[TOTAL_CURR_EFFECT]"
				+ ",[TOTAL_EFFECT],[CREATEDDTTM])" + "VALUES" + "('" + date + "','" + asatdate + "'," + pid + "," + bid
				+ ",'" + repPeriod + "',:total0" + ",:total1" + "," + (totals.get(2).equals("--") ? "NULL" : ":total2")
				+ "," + (totals.get(3).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total3))") + ","
				+ (totals.get(4).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total4))") + ","
				+ (totals.get(5).equals("--") ? "NULL" : ":total5") + ","
				+ (totals.get(6).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total6))") + ","
				+ (totals.get(7).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total7))") + ","
				+ (totals.get(8).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total8))") + ","
				+ (totals.get(9).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total9))") + ","
				+ (totals.get(10).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total10))") + ","
				+ (totals.get(11).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total11))") + ","
				+ (totals.get(12).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total12))") + ","
				+ (totals.get(13).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total13))") + ","
				+ (totals.get(14).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total14))") + ","
				+ (totals.get(15).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total15))") + ","
				+ (totals.get(16).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total16))")
				+ ",getDate()" + ");";
		;

		params.put("total0", totals.get(0));

		params.put("total1", totals.get(1));
		if (!totals.get(2).equals("--")) {
			params.put("total2", totals.get(2));
		}
		for (int i = 3; i < totals.size(); i++) {
			if (totals.get(i).equals("--")) {
				// params.put("total" + i, "0");

			} else {
				params.put("total" + i, totals.get(i));
			}
		}
		return sql;

	}

	public String insertReturns(String line, String date, Map<String, Object> params, String asatdate, String repPeriod,
			int pid, int bid) {

		ArrayList<String> totals = new ArrayList<String>(Arrays.asList(line.split(";")));

		String sql = "INSERT INTO [ATTR].[FactSet].[SECURITY_RETURN]" + "([ASOFDATE]" + ",[ASATDATE]"
				+ ",[PORTFOLIO_ID]" + ",[BENCHMARK_ID]" + ",[REPORT_PERIOD]" + ",[SECURITY_NAME]" + ",[SECURITY_ID]"
				+ ",[ANALYST_NAME]" + ",[VARIATION_IN_AVG_WEIGHT]" + ",[PORT_BEGINNING_PRICE]" + ",[PORT_ENDING_PRICE]"
				+ ",[PORT_PRICE_RTN]" + ",[PORT_FIXED_INCOME_COUPON_RTN]" + ",[PORT_FIXED_INCOME_PAYDOWN_RTN]"
				+ ",[PORT_AVG_WEIGHT]" + ",[PORT_TOTAL_RTN]" + ",[PORT_CONTRIB_TO_RTN]" + ",[BENCH_AVG_WEIGHT]"
				+ ",[BENCH_TOTAL_RTN]" + ",[BENCH_CONTRIB_TO_RETURN]" + ",[ALLOCATION_EFFECT]" + ",[SELECTION_EFFECT]"
				+ ",[TOTAL_EFFECT],[CREATEDDTTM])" + "VALUES" + "('" + date + "','" + asatdate + "'," + pid + "," + bid
				+ ",'" + repPeriod + "',:total0" + ",:total1" + "," + (totals.get(2).equals("--") ? "NULL" : ":total2")
				+ "," + (totals.get(3).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total3))") + ","
				+ (totals.get(4).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total4))") + ","
				+ (totals.get(5).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total5))") + ","
				+ (totals.get(6).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total6))") + ","
				+ (totals.get(7).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total7))") + ","
				+ (totals.get(8).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total8))") + ","
				+ (totals.get(9).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total9))") + ","
				+ (totals.get(10).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total10))") + ","
				+ (totals.get(11).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total11))") + ","
				+ (totals.get(12).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total12))") + ","
				+ (totals.get(13).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total13))") + ","
				+ (totals.get(14).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total14))") + ","
				+ (totals.get(15).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total15))") + ","
				+ (totals.get(16).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total16))") + ","
				+ (totals.get(17).equals("--") ? "NULL" : "convert(numeric(30,20),convert(real,:total17))")
				+ ",getDate()" + ");";

		params.put("total0", totals.get(0));

		params.put("total1", totals.get(1));
		if (!totals.get(2).equals("--")) {
			params.put("total2", totals.get(2));
		}
		for (int i = 3; i < totals.size(); i++) {
			if (totals.get(i).equals("--")) {
				// params.put("total" + i, "0");

			} else {
				params.put("total" + i, totals.get(i));
			}
		}
		return sql;

	}

	public void loadFactsetReportIntoDB(String dirFile, int reportInstID, int repDefID, Map<String, Object> repDefIds,
			String repPeriod) throws Exception {
		Map<String, Object> analytids = getAnalyticAndAttrIDs();

		int seqno = 0;

		String line = null;

		String[] portBenchString = getPortBenchStrings(dirFile);

		ArrayList<Object[]> tagTree = new ArrayList<Object[]>();

		int pid = lookupPort(portBenchString[0]);

		BufferedReader br = new BufferedReader(new FileReader(dirFile));
		for (int i = 0; i < 9; i++) {
			line = br.readLine();
		}

		int grandTotalTagID = loadGrandTotalRowIntoDB(reportInstID, repDefID, analytids, line, seqno, repDefIds, pid,
				hyports);
		seqno++;
		line = br.readLine();

		while ((line = br.readLine()) != null) {
			if (!line.contains(";;;;;;;;;;;;")) {
				if (line.contains(">>")) {
					loadReportRowIntoDB(line, reportInstID, repDefID, analytids, seqno, repDefIds, pid, tagTree,
							hyports);

				} else {
					loadTotalRowIntoDB(reportInstID, line, repDefID, grandTotalTagID, analytids, seqno, repDefIds, pid,
							hyports);
				}
				seqno++;
			} else {
				break;
			}
		}
		br.close();
		LOGGER.info("loaded report with instance id of: " + reportInstID + " portfolio: " + portBenchString[0]
				+ " benchmark: " + portBenchString[1] + "asofdate: " + getStartAndEndDates(dirFile)[1]
				+ " reportPeriod: " + repPeriod);

	}

	private int loadGrandTotalRowIntoDB(int reportInstID, int repDefID, Map<String, Object> analytids, String line,
			int seqno, Map<String, Object> repDefIds, int pid, ArrayList<Integer> hyports) throws Exception {

		int totalRowID = insertGrandTotalRow(reportInstID, "Total", repDefID, seqno);
		int totalTagID = getTagGroupingInstanceIdFromRowID(totalRowID, reportInstID);
		ArrayList<String> totals = new ArrayList<String>(Arrays.asList(line.split(";")));
		loadReportTotalsIntoDB(totals, totalRowID, analytids, repDefID, repDefIds, pid, hyports);
		return totalTagID;
	}

	private int insertGrandTotalRow(int repInstID, String displayName, int repDefID, int seqno) throws Exception {

		int taggrp = insertTagGroupingInstanceWithNOParent(repInstID, displayName, "Total", repDefID);

		String insertSql = "INSERT INTO reporting.[dbo].[REPORT_ROW_INSTANCE]([REPORT_INSTANCE_ID], [TAG_GROUPING_INSTANCE_ID], [SEQ_NO], [CREATED_BY] ) "
				+ "VALUES( " + repInstID + "  ," + taggrp + "," + seqno + ", 'vkurkal'); SELECT SCOPE_IDENTITY();";

		Map<String, Object> params = new ConcurrentHashMap<String, Object>();
		ResultLite rowins = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, insertSql, null, true);
		int totalsRow = ((BigDecimal) rowins.getData().get(0).get(0)).intValue();
		return totalsRow;

	}

	private int getTagGroupingInstanceIdFromRowID(int row, int repInstID) throws Exception {
		String parentSql = "select tag_grouping_instance_id from reporting.dbo.REPORT_ROW_INSTANCE rri "
				+ "where rri.id = :rowid and rri.report_instance_id = :repinst";
		ConcurrentHashMap<String, Object> params = new ConcurrentHashMap<String, Object>();
		params.put("rowid", Integer.toString(row));
		params.put("repinst", Integer.toString(repInstID));
		ResultLite ans = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, parentSql, null, true);
		return Integer.parseInt((String) ans.getData().get(0).get(0));

	}

	private Map<String, Object> getAnalyticAndAttrIDs() throws Exception {
		Map<String, Object> analytids = new ConcurrentHashMap<String, Object>();

		Map<String, Object> params = new ConcurrentHashMap<String, Object>();
		String analytsql = "select ANALYTIC_ID, NAME from reporting.dbo.ANALYTIC";
		ResultLite ans = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, analytsql, null, true);

		for (List<Object> row : ans.getData()) {
			analytids.put((String) row.get(1), row.get(0));
		}
		analytsql = "select ATTRIBUTE_ID, NAME from reporting.dbo.ATTRIBUTE";
		params.clear();
		ans = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, analytsql, null, true);

		for (List<Object> row : ans.getData()) {
			analytids.put((String) row.get(1), row.get(0));
		}
		return analytids;
	}

	private void prepareLoadExcessTotalReturn(Map<String, Object> params, int totalsRow, List<String> totals,
			Map<String, Object> analytids, StringBuilder insertSql, int portTotalRetInd, int benchTotalRetInd)
			throws Exception {

		BigDecimal portValue;
		BigDecimal benchValue;
		BigDecimal activeValue;

		if (totals.get(portTotalRetInd).equals("--")) {
			portValue = new BigDecimal(0);
		} else {
			portValue = new BigDecimal(totals.get(portTotalRetInd));

		}
		if (totals.get(benchTotalRetInd).equals("--")) {
			benchValue = new BigDecimal(0);
		} else {
			benchValue = new BigDecimal(totals.get(benchTotalRetInd));

		}

		activeValue = portValue.subtract(benchValue);

		insertSql.append(
				loadAnalytic(params, totalsRow, activeValue.toString(), (int) analytids.get("Excess Total Return")));
	}

	private void prepareLoadExcessContrReturn(Map<String, Object> params, int totalsRow, List<String> totals,
			Map<String, Object> analytids, StringBuilder insertSql, int portContrib, int benchContrib)
			throws Exception {

		BigDecimal portValue;
		BigDecimal benchValue;
		BigDecimal activeValue;

		if (totals.get(portContrib).equals("--")) {
			portValue = new BigDecimal(0);
		} else {
			portValue = new BigDecimal(totals.get(portContrib));

		}
		if (totals.get(benchContrib).equals("--")) {
			benchValue = new BigDecimal(0);
		} else {
			benchValue = new BigDecimal(totals.get(benchContrib));

		}

		activeValue = portValue.subtract(benchValue);

		insertSql.append(
				loadAnalytic(params, totalsRow, activeValue.toString(), (int) analytids.get("Excess Contr. Return")));

	}

	private void prepareLoadExcessDuration(Map<String, Object> params, int totalsRow, List<String> totals,
			Map<String, Object> analytids, StringBuilder insertSql, int portDuration, int benchDuration)
			throws Exception {

		BigDecimal portValue;
		BigDecimal benchValue;
		BigDecimal activeValue;

		if (totals.get(portDuration).equals("--")) {
			portValue = new BigDecimal(0);
		} else {
			portValue = new BigDecimal(totals.get(portDuration));

		}
		if (totals.get(benchDuration).equals("--")) {
			benchValue = new BigDecimal(0);
		} else {
			benchValue = new BigDecimal(totals.get(benchDuration));

		}

		activeValue = portValue.subtract(benchValue);

		insertSql.append(loadAnalytic(params, totalsRow, activeValue.toString(),
				(int) analytids.get("Excess Average Duration")));

	}

	private StringBuilder lahyFIAttrRow(Map<String, Object> params, int totalsRow, List<String> totals,
			Map<String, Object> analytids, StringBuilder insertSql) throws Exception {

		insertSql.append(loadAttribute(params, totalsRow, totals.get(1), (int) analytids.get("Symbol")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(2), (int) analytids.get("Variation in Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(3), (int) analytids.get("Port. Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(4), (int) analytids.get("Port. Average Duration")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(5), (int) analytids.get("Port. Total Return")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(6), (int) analytids.get("Port. Contrib. To Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(7), (int) analytids.get("Bench. Average Weight")));

		insertSql
				.append(loadAnalytic(params, totalsRow, totals.get(8), (int) analytids.get("Bench. Average Duration")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(9), (int) analytids.get("Bench. Total Return")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(10), (int) analytids.get("Bench. Contrib. To Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(11), (int) analytids.get("Shift Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(12), (int) analytids.get("Twist Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(13), (int) analytids.get("Spread Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(14), (int) analytids.get("Income Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(15), (int) analytids.get("Allocation Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(16), (int) analytids.get("Selection Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(17), (int) analytids.get("Total Currency Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(18), (int) analytids.get("Total Effect")));

		int portTotalRetInd = 5;
		int benchTotalRetInd = 9;
		int portContrib = 6;
		int benchContrib = 10;
		int portDur = 4;
		int benchDur = 8;

		prepareLoadExcessTotalReturn(params, totalsRow, totals, analytids, insertSql, portTotalRetInd,
				benchTotalRetInd);

		prepareLoadExcessContrReturn(params, totalsRow, totals, analytids, insertSql, portContrib, benchContrib);

		prepareLoadExcessDuration(params, totalsRow, totals, analytids, insertSql, portDur, benchDur);

		return insertSql;

	}

	private StringBuilder lahyDevEMCurrencyRow(Map<String, Object> params, int totalsRow, List<String> totals,
			Map<String, Object> analytids, StringBuilder insertSql) throws Exception {

		insertSql.append(loadAttribute(params, totalsRow, totals.get(1), (int) analytids.get("Symbol")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(2), (int) analytids.get("LA_CUSIP")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(3), (int) analytids.get("Analyst Name")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(4), (int) analytids.get("Port. Price Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(5),
				(int) analytids.get("Port. Fixed Income Coupon Return")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(6), (int) analytids.get("ML_RTG")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(7), (int) analytids.get("LA_ML_INDUSTRY_LVL3")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(8), (int) analytids.get("ML Level 3")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(9), (int) analytids.get("Variation in Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(10), (int) analytids.get("Port. Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(11), (int) analytids.get("Port. Total Return")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(12), (int) analytids.get("Port. Contrib. To Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(13), (int) analytids.get("Bench. Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(14), (int) analytids.get("Bench. Total Return")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(15), (int) analytids.get("Bench. Contrib. To Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(16), (int) analytids.get("Allocation Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(17), (int) analytids.get("Selection Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(18), (int) analytids.get("Total Currency Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(19), (int) analytids.get("Total Effect")));

		int portTotalRetInd = 11;
		int benchTotalRetInd = 14;
		int portContrib = 12;
		int benchContrib = 15;

		prepareLoadExcessTotalReturn(params, totalsRow, totals, analytids, insertSql, portTotalRetInd,
				benchTotalRetInd);

		prepareLoadExcessContrReturn(params, totalsRow, totals, analytids, insertSql, portContrib, benchContrib);

		return insertSql;

	}

	private StringBuilder lahyIssuerRow(Map<String, Object> params, int totalsRow, List<String> totals,
			Map<String, Object> analytids, StringBuilder insertSql) throws Exception {

		insertSql.append(loadAttribute(params, totalsRow, totals.get(1), (int) analytids.get("LA_CUSIP")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(2), (int) analytids.get("Analyst Name")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(3), (int) analytids.get("Port. Price Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(4),
				(int) analytids.get("Port. Fixed Income Coupon Return")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(5), (int) analytids.get("ML_RTG")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(6), (int) analytids.get("LA_ML_INDUSTRY_LVL3")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(7), (int) analytids.get("ML Level 3")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(8), (int) analytids.get("Variation in Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(9), (int) analytids.get("Port. Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(10), (int) analytids.get("Port. Total Return")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(11), (int) analytids.get("Port. Contrib. To Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(12), (int) analytids.get("Bench. Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(13), (int) analytids.get("Bench. Total Return")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(14), (int) analytids.get("Bench. Contrib. To Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(15), (int) analytids.get("Allocation Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(16), (int) analytids.get("Selection Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(17), (int) analytids.get("Total Currency Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(18), (int) analytids.get("Total Effect")));

		int portTotalRetInd = 10;
		int benchTotalRetInd = 13;
		int portContrib = 11;
		int benchContrib = 14;

		prepareLoadExcessTotalReturn(params, totalsRow, totals, analytids, insertSql, portTotalRetInd,
				benchTotalRetInd);

		prepareLoadExcessContrReturn(params, totalsRow, totals, analytids, insertSql, portContrib, benchContrib);

		return insertSql;

	}

	private StringBuilder lahySectorRatingsRow(Map<String, Object> params, int totalsRow, List<String> totals,
			Map<String, Object> analytids, StringBuilder insertSql) throws Exception {

		insertSql.append(loadAttribute(params, totalsRow, totals.get(1), (int) analytids.get("LA_CUSIP")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(2), (int) analytids.get("Port. Price Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(3),
				(int) analytids.get("Port. Fixed Income Coupon Return")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(4), (int) analytids.get("ML_RTG")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(5), (int) analytids.get("Variation in Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(6), (int) analytids.get("Port. Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(7), (int) analytids.get("Port. Total Return")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(8), (int) analytids.get("Port. Contrib. To Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(9), (int) analytids.get("Bench. Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(10), (int) analytids.get("Bench. Total Return")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(11), (int) analytids.get("Bench. Contrib. To Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(12), (int) analytids.get("Allocation Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(13), (int) analytids.get("Selection Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(14), (int) analytids.get("Total Currency Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(15), (int) analytids.get("Total Effect")));

		int portTotalRetInd = 7;
		int benchTotalRetInd = 10;
		int portContrib = 8;
		int benchContrib = 11;

		prepareLoadExcessTotalReturn(params, totalsRow, totals, analytids, insertSql, portTotalRetInd,
				benchTotalRetInd);

		prepareLoadExcessContrReturn(params, totalsRow, totals, analytids, insertSql, portContrib, benchContrib);

		return insertSql;

	}

	private StringBuilder withPayDownReturn(Map<String, Object> params, int totalsRow, List<String> totals,
			Map<String, Object> analytids, StringBuilder insertSql) throws Exception {
		insertSql.append(loadAttribute(params, totalsRow, totals.get(1), (int) analytids.get("Security ID")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(2), (int) analytids.get("Analyst Name")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(3), (int) analytids.get("Variation in Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(4), (int) analytids.get("Port. Beginning Price")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(5), (int) analytids.get("Port. Ending Price")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(6), (int) analytids.get("Port. Price Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(7),
				(int) analytids.get("Port. Fixed Income Coupon Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(8),
				(int) analytids.get("Port. Fixed Income Paydown Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(9), (int) analytids.get("Port. Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(10), (int) analytids.get("Port. Total Return")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(11), (int) analytids.get("Port. Contrib. To Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(12), (int) analytids.get("Bench. Average Weight")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(13), (int) analytids.get("Bench. Total Return")));

		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(14), (int) analytids.get("Bench. Contrib. To Return")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(15), (int) analytids.get("Allocation Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(16), (int) analytids.get("Selection Effect")));

		insertSql.append(loadAnalytic(params, totalsRow, totals.get(17), (int) analytids.get("Total Effect")));

		int portTotalRetInd = 10;
		int benchTotalRetInd = 13;
		int portContrib = 11;
		int benchContrib = 14;

		prepareLoadExcessTotalReturn(params, totalsRow, totals, analytids, insertSql, portTotalRetInd,
				benchTotalRetInd);

		prepareLoadExcessContrReturn(params, totalsRow, totals, analytids, insertSql, portContrib, benchContrib);

		return insertSql;

	}

	private StringBuilder emWithJPMRatingsRow(Map<String, Object> params, int totalsRow, List<String> totals,
			Map<String, Object> analytids, StringBuilder insertSql) throws Exception {

		insertSql.append(loadAttribute(params, totalsRow, totals.get(0), (int) analytids.get("JPM SP Rating")));
		insertSql.append(loadAttribute(params, totalsRow, totals.get(1), (int) analytids.get("JPM MOODY Rating")));

		insertSql.append(loadAttribute(params, totalsRow, totals.get(2), (int) analytids.get("Sector")));
		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(3), (int) analytids.get("Variation in Average Weight")));
		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(4), (int) analytids.get("Variation in Ending Weight")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(5), (int) analytids.get("Excess Contr. Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(6), (int) analytids.get("Total Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(7), (int) analytids.get("Allocation Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(8), (int) analytids.get("Selection Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(9), (int) analytids.get("Selection Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(10), (int) analytids.get("Total Currency Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(11), (int) analytids.get("Spread Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(12), (int) analytids.get("Shift Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(13), (int) analytids.get("Twist Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(14), (int) analytids.get("Income Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(15), (int) analytids.get("Port. Average Weight")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(16), (int) analytids.get("Port. Ending Weight")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(17), (int) analytids.get("Port. Total Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(18), (int) analytids.get("Port. Price Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(19),
				(int) analytids.get("Port. Fixed Income Coupon Return")));
		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(20), (int) analytids.get("Port. Contrib. To Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(21), (int) analytids.get("Bench. Average Weight")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(22), (int) analytids.get("Bench. Ending Weight")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(23), (int) analytids.get("Bench. Total Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(24), (int) analytids.get("Bench. Price Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(25),
				(int) analytids.get("Bench. Fixed Income Coupon Return")));
		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(26), (int) analytids.get("Bench. Contrib. To Return")));

		return insertSql;
	}

	private StringBuilder emDefaultRow(Map<String, Object> params, int totalsRow, List<String> totals,
			Map<String, Object> analytids, StringBuilder insertSql) throws Exception {

		insertSql.append(loadAttribute(params, totalsRow, totals.get(0), (int) analytids.get("Sector")));
		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(1), (int) analytids.get("Variation in Average Weight")));
		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(2), (int) analytids.get("Variation in Ending Weight")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(3), (int) analytids.get("Excess Contr. Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(4), (int) analytids.get("Total Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(5), (int) analytids.get("Allocation Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(5), (int) analytids.get("Selection Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(6), (int) analytids.get("Selection Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(7), (int) analytids.get("Total Currency Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(8), (int) analytids.get("Spread Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(9), (int) analytids.get("Shift Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(10), (int) analytids.get("Twist Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(11), (int) analytids.get("Income Effect")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(12), (int) analytids.get("Port. Average Weight")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(13), (int) analytids.get("Port. Ending Weight")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(14), (int) analytids.get("Port. Total Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(15), (int) analytids.get("Port. Price Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(16),
				(int) analytids.get("Port. Fixed Income Coupon Return")));
		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(17), (int) analytids.get("Port. Contrib. To Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(18), (int) analytids.get("Bench. Average Weight")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(19), (int) analytids.get("Bench. Ending Weight")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(20), (int) analytids.get("Bench. Total Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(21), (int) analytids.get("Bench. Price Return")));
		insertSql.append(loadAnalytic(params, totalsRow, totals.get(22),
				(int) analytids.get("Bench. Fixed Income Coupon Return")));
		insertSql.append(
				loadAnalytic(params, totalsRow, totals.get(23), (int) analytids.get("Bench. Contrib. To Return")));

		return insertSql;
	}

	private void loadReportTotalsIntoDB(List<String> totals, int totalsRow, Map<String, Object> analytids, int repDefID,
			Map<String, Object> repDefIds, int pid, ArrayList<Integer> hyports) throws Exception {

		StringBuilder insertSql = new StringBuilder();
		Map<String, Object> params = new ConcurrentHashMap<String, Object>();
		if (totals.size() > 1) {
			Integer currentPort = new Integer(pid);
			try {
				if (hyports.contains(currentPort)) {
					if (repDefID == (int) repDefIds.get("Attribution_by_Ratings.txt".toLowerCase())
							|| repDefID == (int) repDefIds.get("Attribution_by_Sectors.txt".toLowerCase())
							|| repDefID == (int) repDefIds.get("Attribution_by_Sectors(asset_ty.txt".toLowerCase())
							|| repDefID == (int) repDefIds.get("Attribution_by_Sectors(ratings).txt".toLowerCase())) {
						insertSql = lahySectorRatingsRow(params, totalsRow, totals, analytids, insertSql);
					} else if (repDefID == (int) repDefIds.get("Attribution_by_Issuers.txt".toLowerCase())) {
						insertSql = lahyIssuerRow(params, totalsRow, totals, analytids, insertSql);
					} else if (repDefID == (int) repDefIds.get("Attribution_by_Currency.txt".toLowerCase())
							|| repDefID == (int) repDefIds.get("Attribution_by_Developed_EM_Mar.txt".toLowerCase())) {
						insertSql = lahyDevEMCurrencyRow(params, totalsRow, totals, analytids, insertSql);
					} else if (repDefID == (int) repDefIds.get("Fixed_Income_Attribution.txt".toLowerCase())) {
						insertSql = lahyFIAttrRow(params, totalsRow, totals, analytids, insertSql);
					}

				} else if (emports.contains(currentPort)) {
					if (repDefID == (int) repDefIds.get("IG_HY-Region-Country-Issuer.txt".toLowerCase())) {
						insertSql = emWithJPMRatingsRow(params, totalsRow, totals, analytids, insertSql);
					} else {
						insertSql = emDefaultRow(params, totalsRow, totals, analytids, insertSql);

					}
				}

				else {
					insertSql = withPayDownReturn(params, totalsRow, totals, analytids, insertSql);
				}

			} catch (Exception e) {
				e.getMessage();
			}
			try {
				insertSql.append("SELECT SCOPE_IDENTITY();");
				baseDAO.findUsingSQL(idaJdbcTemplate, params, insertSql.toString(), null, true);
			} catch (Exception e) {

				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);

				baseService.emailReportListLoaded(sw.toString());
				e.printStackTrace();
				// throw e;
			}
		}
	}

	/**
	 * Adds the given attribute to the Report Row Instance denoted by the rowId,
	 * value is parsed from the .txt from preprocessed .xlsx
	 * 
	 * @param params
	 *            (Map[String,Object]) parameters to pass for SQL parameterized
	 *            Input
	 * @param rowId
	 *            (int) the report row instance's id to add the attribute to
	 * @param value
	 *            (String) the value of the attribute to add, parsed from the XML
	 *            file
	 * @param attribute
	 *            (int) the id of the attribute type
	 * @throws Exception
	 */
	private String loadAttribute(Map<String, Object> params, int rowId, String value, int attribute) throws Exception {
		if (value.length() > 0 && !value.contains("--") && !value.equals(" ") && !value.contains("N.A.")) {
			// params.clear();
			String companyNameSql = "INSERT INTO reporting.[dbo].[REPORT_ROW_ATTRIBUTE_DATA]([REPORT_ROW_INSTANCE_ID], [ATTRIBUTE_ID], [DATA], [CREATED_BY])"
					+ "	VALUES(" + ":totalsRow" + attribute + "," + ":attribute" + attribute + "," + ":total"
					+ attribute + ", 'vkurkal' ); ";
			params.put("attribute" + attribute, Integer.toString(attribute));
			params.put("totalsRow" + attribute, Integer.toString(rowId));

			params.put("total" + attribute, value);
			return companyNameSql;
			// baseDAO.findUsingSQL(idaJdbcTemplate, params, companyNameSql, null, true);
		}
		return "";
	}

	/**
	 * Adds the given analytic to the Report Row Instance denoted by the rowId,
	 * value is parsed from the .txt from preprocessed .xlsx
	 * 
	 * @param params
	 * @param totalsRow
	 * @param value
	 * @param analytic
	 * @throws Exception
	 */
	private String loadAnalytic(Map<String, Object> params, int totalsRow, String value, int analytic)
			throws Exception {

		BigDecimal decVal;
		String priceSql;

		try {
			decVal = new BigDecimal(value);
			priceSql = "INSERT INTO reporting.[dbo].[REPORT_ROW_ANALYTIC_DATA]([REPORT_ROW_INSTANCE_ID], [ANALYTIC_ID], [DATA], [CREATED_BY])"
					+ "	VALUES(" + ":totalsRow" + analytic + "," + ":analytic" + analytic + ","
					+ "convert(numeric(30,10),convert(real,:total" + analytic + ")) " + ", 'vkurkal' ); ";
			params.put("totalsRow" + analytic, Integer.toString(totalsRow));
			params.put("analytic" + analytic, Integer.toString(analytic));
			params.put("total" + analytic, decVal.toString());

			return priceSql;
		} catch (NumberFormatException e) {

			return "";

		}
	}

	public ArrayList<Integer> listOfAccountsbyRunType(String runType) throws Exception {
		ArrayList<Integer> hyports = new ArrayList<Integer>();

		String sql = "select RunTypeID from attr.ingen.runtype where Type = :type";
		Map<String, Object> params = new ConcurrentHashMap<String, Object>();

		params.put("type", runType);

		ResultLite hyid = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, sql, null, true);
		int hyrunid = ((BigDecimal) hyid.getData().get(0).get(0)).intValue();

		String hyportsql = "select Portfolio_ID from attr.ingen.activeaccounts where runtypeid = :runtypeid";

		params.clear();
		params.put("runtypeid", Integer.toString(hyrunid));

		ResultLite hyportlist = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, hyportsql, null, true);
		List<List<Object>> rows = hyportlist.getData();
		for (List<Object> row : rows) {
			hyports.add(new Integer(((BigDecimal) row.get(0)).intValue()));
		}

		return hyports;
	}

}
