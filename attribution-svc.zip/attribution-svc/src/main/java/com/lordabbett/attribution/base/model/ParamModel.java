package com.lordabbett.attribution.base.model;

public class ParamModel {

	String uiParam;
	String sqlParam;
	String uiValue;

	public String getUiParam() {
		return uiParam;
	}

	public void setUiParam(String uiParam) {
		this.uiParam = uiParam;
	}

	public String getSqlParam() {
		return sqlParam;
	}

	public void setSqlParam(String sqlParam) {
		this.sqlParam = sqlParam;
	}

	public String getUiValue() {
		return uiValue;
	}

	public void setUiValue(String uiValue) {
		this.uiValue = uiValue;
	}

}
