package com.lordabbett.attribution.base.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class DataSourceConfig {

	@Bean(name = "sqlIdaDataSource")
	@ConfigurationProperties(prefix = "idadata.datasource")
	@Primary
	DataSource idaDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	@Qualifier("idaJdbcTemplate")
	JdbcTemplate idaJdbcTemplate(@Qualifier("sqlIdaDataSource") DataSource idaDataSource) {
		return new JdbcTemplate(idaDataSource);
	}

	@Bean(name = "lcapxPortfoliosDataSourceBean")
	@ConfigurationProperties(prefix = "postgresql.portfolio.datasource")
	DataSource getLcapxPortfolioDataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean
	@Qualifier("lcapxPortfoliosJdbcTemplate")
	JdbcTemplate getBbgJdbcTemplate(@Qualifier("lcapxPortfoliosDataSourceBean") DataSource lcapxPortfoliosDataSourceBean) {
		return new JdbcTemplate(lcapxPortfoliosDataSourceBean);
	}

}
