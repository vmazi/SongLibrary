package com.lordabbett.attribution.base.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class KafkaFactory {

	private static final Logger LOGGER = LoggerFactory.getLogger(KafkaFactory.class);

	@Value("${spring.kafka.bootstrap-servers:#{null}}")
	private String bootstrapServers;

	@Value("${spring.kafka.ssl.truststore-location:kafka.client.truststore.jks}")
	private String trustStoreFilename;

	@Value("${spring.kafka.ssl.truststore-password:kafkadev}")
	private String trustStorePassword;

	@Value("${spring.kafka.properties.security.protocol:SASL_SSL}")
	private String securityProtocol;

	@Value("${spring.kafka.properties.sasl.mechanism:PLAIN}")
	private String saslMechanism;

	@Value("${spring.kafka.properties.consumer.sasl.jaas.config:org.apache.kafka.common.security.plain.PlainLoginModule required username=\"%s\" password=\"%s\";}")
	private String saslJaasConfig;

	@SuppressWarnings("rawtypes")
	public <K, V> ConsumerFactory<K, V> createConsumerFactory(String groupId, String consumerUsername,
			String consumerPassword, Class<? extends Deserializer> keyDeserializer,
			Class<? extends Deserializer> valueDeserializer) {
		Map<String, Object> props = new HashMap<>();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, keyDeserializer);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, valueDeserializer);
		addKafkaSecurityProperties(props, consumerUsername, consumerPassword);
		return new DefaultKafkaConsumerFactory<>(props);
	}

	public <K, V> ConsumerFactory<K, V> createConsumerFactory(String groupId, String consumerUsername,
			String consumerPassword) {
		return createConsumerFactory(groupId, consumerUsername, consumerPassword, StringDeserializer.class,
				JsonDeserializer.class);
	}

	@SuppressWarnings("rawtypes")
	public <K, V> ProducerFactory<K, V> createProducerFactory(String clientId, String producerUsername,
			String producerPassword, Class<? extends Serializer> keySerializer,
			Class<? extends Serializer> valueSerializer) {
		Map<String, Object> props = new HashMap<>();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
		props.put(ProducerConfig.CLIENT_ID_CONFIG, clientId);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, keySerializer);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, valueSerializer);
		addKafkaSecurityProperties(props, producerUsername, producerPassword);
		return new DefaultKafkaProducerFactory<>(props);
	}

	public <K, V> ProducerFactory<K, V> createProducerFactory(String clientId, String producerUsername,
			String producerPassword) {
		return createProducerFactory(clientId, producerUsername, producerPassword, StringSerializer.class,
				JsonSerializer.class);
	}

	protected void addKafkaSecurityProperties(Map<String, Object> props, String saslUsername, String saslPassword) {
		props.put("security.protocol", securityProtocol);
		props.put("sasl.mechanism", saslMechanism);
		props.put("sasl.jaas.config", String.format(saslJaasConfig, saslUsername, saslPassword));

		// ClassPathResource trustStore = new ClassPathResource(trustStoreFilename);

		try {
			InputStream trustStream = KafkaFactory.class.getResourceAsStream("/"+trustStoreFilename);
			FileCopyUtils.copy(trustStream, new FileOutputStream(trustStoreFilename));

			File trustStoreFile = new File(trustStoreFilename);
			props.put("ssl.truststore.location", trustStoreFile.getAbsolutePath());
			// props.put("ssl.truststore.location", trustStore.getPath());
			props.put("ssl.truststore.password", trustStorePassword);
		} catch (Exception ex) {
			LOGGER.error("Failed to load the Kafka trust store:", ex);
		}
	}

}