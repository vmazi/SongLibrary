package com.lordabbett.attribution.base.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.lordabbett.attribution.base.model.BaseModel;
import com.lordabbett.attribution.base.model.ColumnMetaData;
import com.lordabbett.attribution.base.model.Result;
import com.lordabbett.attribution.base.model.ResultLite;
import com.lordabbett.attribution.web.util.ParamUtil;

@Component("BaseDAO")
public class BaseDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(BaseDAO.class);
	private static SimpleDateFormat dt1 = new SimpleDateFormat("yyyyMMdd");

	@Autowired
	private ParamUtil paramUtil;

	public Result findUsingSQL(JdbcTemplate jdbcTemplate, Map<String, Object> params, String sql) throws Exception {
		return findUsingSQL(jdbcTemplate, params, sql, null);
	}

	public Result findUsingSQL(JdbcTemplate jdbcTemplate, Map<String, Object> params, String sql, String database_name)
			throws Exception {
		boolean returnResultLite = false;
		return (Result) findUsingSQL(jdbcTemplate, params, sql, database_name, returnResultLite);

	}

	public BaseModel findUsingSQL(JdbcTemplate jdbcTemplate, Map<String, Object> params, String sql,
			String database_name, boolean returnResultLite) throws Exception {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement ps = null;

		NamedParameterStatement nps = null;

		try {
			conn = jdbcTemplate.getDataSource().getConnection();
			ParamUtil.SqlStatementType statementType = paramUtil.getSqlStatementType(sql);
			if (statementType == ParamUtil.SqlStatementType.CallableStatement) {

				conn = jdbcTemplate.getDataSource().getConnection();
				if (database_name != null) {
					conn.setCatalog(database_name);
				}
				// LOGGER.debug("executing stored procedure {} with {}", sql, params);

				CallableStatement cs = conn.prepareCall(sql);
				Iterator<Map.Entry<String, Object>> it = params.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry<String, Object> pair = (Map.Entry<String, Object>) it.next();
					cs.setString(pair.getKey(), ((String) pair.getValue()).split(";")[0]);

				}
				rs = cs.executeQuery();

			} else if (statementType == ParamUtil.SqlStatementType.NamedParameterStatement) {

				if (database_name != null) {
					conn.setCatalog(database_name);
				}

				nps = new NamedParameterStatement(conn, sql);
				Iterator<Map.Entry<String, Object>> it = params.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry<String, Object> pair = (Map.Entry<String, Object>) it.next();
					nps.setString((String) pair.getKey(), ((String) pair.getValue()).split(";")[0]);

				}
				// LOGGER.debug("executing {} with {}", sql, params);
				rs = nps.executeQuery();

			} else {
				ps = conn.prepareStatement(sql);
				Iterator<Map.Entry<String, Object>> it = params.entrySet().iterator();
				int index = 1;
				while (it.hasNext()) {
					Map.Entry<String, Object> pair = (Map.Entry<String, Object>) it.next();
					ps.setString(index, ((String) pair.getValue()).split(";")[0]);
					index++;
				}
				// LOGGER.debug("executing sql {}", sql);
				rs = ps.executeQuery();
			}

			return getData(rs, returnResultLite);

		} catch (Exception ex) {
			LOGGER.error("failed to execute ", ex);
			throw ex;
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (ps != null) {
				ps.close();
			}
			if (nps != null) {
				nps.close();
			}
			if (conn != null) {
				conn.close();
			}
		}

	}

	public void updateUsingSql(JdbcTemplate jdbcTemplate, Map<String, Object> params, String sql, String database_name,
			boolean returnResultLite) throws Exception {
		Connection conn = null;
		int rs = -1;
		PreparedStatement ps = null;

		NamedParameterStatement nps = null;

		try {
			conn = jdbcTemplate.getDataSource().getConnection();
			ParamUtil.SqlStatementType statementType = paramUtil.getSqlStatementType(sql);
			if (statementType == ParamUtil.SqlStatementType.CallableStatement) {

				conn = jdbcTemplate.getDataSource().getConnection();
				if (database_name != null) {
					conn.setCatalog(database_name);
				}
				// LOGGER.debug("executing stored procedure {} with {}", sql, params);

				CallableStatement cs = conn.prepareCall(sql);
				Iterator<Map.Entry<String, Object>> it = params.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry<String, Object> pair = (Map.Entry<String, Object>) it.next();
					cs.setString(pair.getKey(), ((String) pair.getValue()).split(";")[0]);

				}
				rs = cs.executeUpdate();

			} else if (statementType == ParamUtil.SqlStatementType.NamedParameterStatement) {

				if (database_name != null) {
					conn.setCatalog(database_name);
				}

				nps = new NamedParameterStatement(conn, sql);
				Iterator<Map.Entry<String, Object>> it = params.entrySet().iterator();
				while (it.hasNext()) {
					Map.Entry<String, Object> pair = (Map.Entry<String, Object>) it.next();
					nps.setString((String) pair.getKey(), ((String) pair.getValue()).split(";")[0]);

				}
				// LOGGER.debug("executing {} with {}", sql, params);
				rs = nps.executeUpdate();

			} else {
				ps = conn.prepareStatement(sql);
				Iterator<Map.Entry<String, Object>> it = params.entrySet().iterator();
				int index = 1;
				while (it.hasNext()) {
					Map.Entry<String, Object> pair = (Map.Entry<String, Object>) it.next();
					ps.setString(index, ((String) pair.getValue()).split(";")[0]);
					index++;
				}
				// LOGGER.debug("executing sql {}", sql);
				rs = ps.executeUpdate();
			}

		} catch (Exception ex) {
			LOGGER.error("failed to execute ", ex);
			throw ex;
		}

	}

	private BaseModel getData(ResultSet rs, boolean returnResultLite) throws SQLException {
		if (returnResultLite) {
			return getDataLite(rs);
		} else {
			return getData(rs);
		}
	}

	Result getData(ResultSet rs) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData();
		List<ColumnMetaData> columns = new ArrayList<>();
		List<Map<String, String>> data = new ArrayList<>();
		Result result = new Result();
		result.setColumns(columns);
		result.setData(data);

		int columnCount = rsmd.getColumnCount();

		for (int i = 1; i <= columnCount; i++) {
			ColumnMetaData columnMetaData = new ColumnMetaData();
			columnMetaData.setName(rsmd.getColumnName(i));
			columnMetaData.setType(rsmd.getColumnTypeName(i));
			columns.add(columnMetaData);
		}
		while (rs.next()) {
			Map<String, String> rowData = new HashMap<>();
			int i = 0;
			for (ColumnMetaData columnMetaData : columns) {
				String value = "";
				if (columnMetaData.getType().equalsIgnoreCase("datetime")
						|| columnMetaData.getType().equalsIgnoreCase("datetime2")
						|| columnMetaData.getType().equalsIgnoreCase("date")) {
					Date temp = rs.getDate(columnMetaData.getName());
					if (temp != null) {
						value = dt1.format(temp);
					}

				} else {
					value = rs.getString(columnMetaData.getName());
					value = value == null ? "" : value;
				}
				rowData.put(columnMetaData.getName(), value);
			}
			data.add(rowData);
		}
		return result;

	}

	private ResultLite getDataLite(ResultSet rs) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData();
		List<ColumnMetaData> columns = new ArrayList<>();
		List<List<Object>> data = new ArrayList<>();
		ResultLite result = new ResultLite();
		result.setColumns(columns);
		result.setData(data);

		int columnCount = rsmd.getColumnCount();

		for (int i = 1; i <= columnCount; i++) {
			ColumnMetaData columnMetaData = new ColumnMetaData();
			columnMetaData.setName(rsmd.getColumnName(i));
			columnMetaData.setType(rsmd.getColumnTypeName(i));
			columns.add(columnMetaData);
		}
		while (rs.next()) {
			List<Object> rowData = new ArrayList<>();
			int i = 0;
			for (ColumnMetaData columnMetaData : columns) {
				Object value = null;
				switch (columnMetaData.getType()) {
				case "datetime":
				case "datetime2":
				case "date":
					Date temp = rs.getDate(columnMetaData.getName());
					if (temp != null) {
						value = dt1.format(temp);
					}
					break;
				case "decimal":
				case "numeric":
					value = rs.getBigDecimal(columnMetaData.getName());
					break;
				case "float":
					value = rs.getDouble(columnMetaData.getName());
					break;
				case "bit":
					value = rs.getBoolean(columnMetaData.getName());
					break;
				case "varchar":
				case "char":
					value = rs.getString(columnMetaData.getName());
					break;
				case "int":
					value = rs.getInt(columnMetaData.getName());
					break;
				default:
					value = rs.getString(columnMetaData.getName());
					break;
				}
				if (value == null) {
					value = "";
				}
				rowData.add(i++, value);
			}
			data.add(rowData);
		}
		// LOGGER.debug("rows returned are " + result.getData().size());
		return result;
	}

	public Map<String, Object> updateOverride(String sql, JdbcTemplate jdbcTemplate, Map<String, Object> jsonInput)
			throws Exception {
		Map<String, Object> result = new ConcurrentHashMap<String, Object>();
		Connection conn = null;
		SortedMap<String, Integer> converter = new TreeMap<String, Integer>();
		if (sql.indexOf("Analytic") >= 0) {
			converter.put("sourceId", 1);
			converter.put("instrumentId", 2);
			converter.put("analyticId", 3);
			converter.put("analyticValue", 4);
			converter.put("asofDate", 5);
			converter.put("userId", 6);
		} else {
			converter.put("sourceId", 1);
			converter.put("instrumentId", 2);
			converter.put("attributeId", 3);
			converter.put("attributeValue", 4);
			converter.put("asofDate", 5);
			converter.put("userId", 6);
		}

		try {
			conn = jdbcTemplate.getDataSource().getConnection();
			CallableStatement cs = conn.prepareCall(sql);
			Iterator<Map.Entry<String, Object>> jsonIterator = jsonInput.entrySet().iterator();
			while (jsonIterator.hasNext()) {
				Map.Entry<String, Object> pair = (Map.Entry<String, Object>) jsonIterator.next();
				String key = pair.getKey();
				Integer sqlParamPos = converter.get(key);
				if (sqlParamPos == null) {
					continue;
				}
				String value = (String) pair.getValue();
				cs.setString(sqlParamPos, value);
			}
			cs.executeUpdate();
			result.put("resultStatus", "SUCCESS");
			result.put("resultDescription", "");

		} catch (Exception exc) {
			LOGGER.error(exc.getMessage());
			result.put("resultStatus", "FAILURE");
			result.put("resultDescription", exc.getMessage());
			// throw exc;

		} finally {
			if (conn != null) {
				conn.close();
			}
		}
		return result;

	}
}
