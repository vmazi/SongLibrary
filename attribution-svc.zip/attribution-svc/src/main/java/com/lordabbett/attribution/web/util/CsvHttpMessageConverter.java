package com.lordabbett.attribution.web.util;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;

import com.fasterxml.jackson.databind.SequenceWriter;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.lordabbett.attribution.base.model.ColumnMetaData;
import com.lordabbett.attribution.base.model.Result;


public class CsvHttpMessageConverter extends AbstractHttpMessageConverter<Result> {

	private static final Logger LOGGER = LoggerFactory.getLogger(CsvHttpMessageConverter.class);
	public CsvHttpMessageConverter() {
		super(new MediaType("text", "csv"));
	}

	@Override
	protected boolean supports(Class<?> clazz) {
		return Result.class.isAssignableFrom(clazz);
	}

	@Override
	protected Result readInternal(Class<? extends Result> clazz, HttpInputMessage inputMessage)
			throws IOException, HttpMessageNotReadableException {
		
		return null;
	}

	@Override
	protected void writeInternal(Result result, HttpOutputMessage outputMessage)
			throws IOException, HttpMessageNotWritableException {
		try {
			OutputStream outputStream = outputMessage.getBody();
			List<Map<String, String>> listOfMap= result.getData();
			List<ColumnMetaData> columns= result.getColumns();
		
			CsvSchema schema = null;
	        CsvSchema.Builder schemaBuilder = CsvSchema.builder();
	        if (columns != null && !columns.isEmpty()) {
	            for (ColumnMetaData col : columns) {
	                schemaBuilder.addColumn(col.getName());
	            }
	            schema = schemaBuilder.build().withLineSeparator("\r\n").withHeader();
	        }

	        CsvMapper mapper = new CsvMapper();
	        SequenceWriter writer = mapper.writer(schema).writeValues(outputStream);
	        int i = 0;
	        for(Map<String, String> map: listOfMap) {
	        	writer.write(map);
	        	//added this to reduce memory print
	        	map.clear();
	        	if(i++ % 5000 == 0) {
	        		outputStream.flush();
	        	}
	        }
			outputStream.close();
		} catch (Exception e) {
			LOGGER.error("failed to write in csv format", e);
		}
	}

	
}
