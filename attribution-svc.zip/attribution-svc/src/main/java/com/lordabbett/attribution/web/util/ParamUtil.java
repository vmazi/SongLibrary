package com.lordabbett.attribution.web.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ParamUtil {
	public static final String DATASET_NAME = "datasetName";
	public static final String DATASET_ID = "datasetId";
	public static final String DATA_SOURCE_ID = "DATA_SOURCE_ID";
	public static final String DATABASE_NAME = "DATABASE_NAME";
	public static final String SQL_STATEMENT = "SQL_STATEMENT";
	public static final Object SQL_PARAM = "SQL_PARAM";
	public static final String COL_PARAM = "columns";
	public static final String ZIP_PARAM = "zipFormat";
	public static final Object ASOF_DATE = "asofDate";
	public static final String FROM_DATE = "fromDate";
	public static final String TO_DATE = "toDate";

	public static final Map<String, String> requestParameterToColumnMap = new HashMap<>();
	public static final Object IS_TIMESERIES = "is_timeseries";
	public static final Object SUPPORTED_FORMATS = "supported_formats";

	public enum SqlStatementType {
		PreparedStatement, NamedParameterStatement, CallableStatement
	}

	static {
		requestParameterToColumnMap.put("DefinitionRule", "ProcessType");
		requestParameterToColumnMap.put("TargetSystem", "ov.TargetSystem");
		requestParameterToColumnMap.put("PathID", "ov.PathID");
		requestParameterToColumnMap.put("SecurityLevel1", "PathOpsCodeDesc1");
		requestParameterToColumnMap.put("SecurityLevel2", "PathOpsCodeDesc2");
		requestParameterToColumnMap.put("SecurityLevel3", "PathOpsCodeDesc3");

	}

	public SqlStatementType getSqlStatementType(String sql) {
		if (sql.indexOf("CALL ") != -1 || sql.indexOf("call ") != -1) {
			return SqlStatementType.CallableStatement;
		} else if (sql.indexOf("?") != -1) {
			return SqlStatementType.PreparedStatement;
		}
		return SqlStatementType.NamedParameterStatement;

	}

	public Map<String, Object> getUiParams(HttpServletRequest request) {
		Map<String, String[]> orgRequestParams = request.getParameterMap();
		Map<String, Object> linked = new ConcurrentHashMap<String, Object>();
		orgRequestParams.entrySet().stream().map(entry -> linked.put(entry.getKey(), entry.getValue()[0])).count();
		return linked;
	}

	public Map<String, Object> getAdditionalParametersFromUIParams(Map<String, Object> uiParams) {
		Map<String, Object> params = new ConcurrentHashMap<String, Object>();

		for (Entry<String, Object> entry : uiParams.entrySet()) {
			params.put(entry.getKey(), entry.getValue());

		}

		params.remove(DATASET_NAME);
		return params;

	}

	public String addSearchCriteriaFromRequestParametersToSql(String searchSql, Map<String, Object> params,
			Map<String, String> requestParamMap) {
		if (params.size() > 0) {
			String whereClauseSql = params.entrySet().stream().map(entry -> requestParamMap.containsKey(entry.getKey())
					? (entry.getKey().equals("TargetSystem") && (((String) entry.getValue()).equalsIgnoreCase("PORT")
							|| ((String) entry.getValue()).equalsIgnoreCase("Base")))
									? requestParamMap.get(entry.getKey()) + " IN ('PORT','Base')"
									: entry.getKey().equals("PathID")
											? requestParamMap.get(entry.getKey()) + " LIKE '%" + entry.getValue() + "%'"
											: requestParamMap.get(entry.getKey()) + " = '" + entry.getValue() + "'"

					: entry.getKey() + " = '" + entry.getValue() + "'").collect(Collectors.joining(" and "));
			return addWhereClauseWithOrderPreserved(searchSql, whereClauseSql);
		}
		return searchSql;

	}

	private String addWhereClauseWithOrderPreserved(String searchSql, String whereClauseSql) {
		if (searchSql.contains("order by")) {
			int fromIndex = searchSql.indexOf("order");
			String beforeSql = searchSql.substring(0, fromIndex);
			String orderSql = searchSql.substring(fromIndex);
			return beforeSql + " and " + whereClauseSql + " " + orderSql;
		} else {
			return generateSearchClause(searchSql, whereClauseSql);

		}

	}

	public String generateSearchClause(String catalogSearchDefaultCriterialSql, String whereClauseSql) {

		if (catalogSearchDefaultCriterialSql.contains("WHERE") || catalogSearchDefaultCriterialSql.contains("where")
				|| catalogSearchDefaultCriterialSql.contains("Where")) {
			catalogSearchDefaultCriterialSql = catalogSearchDefaultCriterialSql + " AND " + whereClauseSql;
		} else {
			if (whereClauseSql.contains("AND")) {
				whereClauseSql = whereClauseSql.substring(whereClauseSql.indexOf("AND") + 3);
				catalogSearchDefaultCriterialSql = catalogSearchDefaultCriterialSql + " where " + whereClauseSql;
			} else {
				catalogSearchDefaultCriterialSql = catalogSearchDefaultCriterialSql + " where " + whereClauseSql;

			}
		}
		return catalogSearchDefaultCriterialSql;
	}

	public Map<String, Object> getMapFromRequestJson(HttpServletRequest request) throws Exception {
		String json = request.getReader().lines().collect(Collectors.joining());

		ObjectMapper mapper = new ObjectMapper();

		Map<String, Object> params = new HashMap<String, Object>();

		params = mapper.readValue(json, new TypeReference<Map<String, Object>>() {
		});
		return params;

	}

}
