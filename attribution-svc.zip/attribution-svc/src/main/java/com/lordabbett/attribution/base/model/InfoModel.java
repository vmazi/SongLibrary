package com.lordabbett.attribution.base.model;

public class InfoModel extends ResultLite {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1558473655035959398L;

	public InfoModel(String string) {
		this.setMessage(string);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	private String message;

}
