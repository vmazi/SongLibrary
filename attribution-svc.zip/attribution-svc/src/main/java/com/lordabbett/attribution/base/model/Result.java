package com.lordabbett.attribution.base.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Result extends BaseModel {

	private static final long serialVersionUID = 5605557963560146693L;
	 @JsonIgnore
	private List<ColumnMetaData> columns;

	private List<Map<String, String>> data;

	public List<Map<String, String>> getData() {
		return data;
	}

	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}

	public List<ColumnMetaData> getColumns() {
		return columns;
	}

	public void setColumns(List<ColumnMetaData> columns) {
		this.columns = columns;
	}

}
