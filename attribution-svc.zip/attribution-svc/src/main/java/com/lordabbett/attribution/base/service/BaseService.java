package com.lordabbett.attribution.base.service;

import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lordabbett.attribution.base.dao.BaseDAO;
import com.lordabbett.attribution.base.model.BaseModel;
import com.lordabbett.attribution.base.model.InfoModel;
import com.lordabbett.attribution.base.model.ResultLite;
import com.lordabbett.attribution.web.util.ParamUtil;

@Service
public class BaseService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BaseService.class);

	@Autowired
	protected BaseDAO baseDAO;

	@Autowired
	protected ParamUtil paramUtil;

	protected JdbcTemplate idaJdbcTemplate;

	protected JdbcTemplate postgreidaJdbcTemplate;

	@Value("${attrSendEmail}")
	protected String attrSendEmail;

	@Value("${version}")
	private String version;

	@Value("${confFile}")
	private String confFile;

	@Value("${FactSetConf}")
	private String factSetConf;

	@Value("${PortConf}")
	private String portConf;

	@Value("${FILEPREFIX}")
	private String filePrefix;

	@Value("${attr.processRules.sql}")
	private String processRulesSql;

	@Value("${udi.getUDI.sql}")
	private String getUDIListSql;

	@Value("${attribution.getMSList.sql}")
	private String getMSListSql;

	@Value("${attribution.getMSListKeyValue.sql}")
	private String getMSListKeyValueSql;

	@Value("${attribution.getMslSearch.sql}")
	private String getMslSearchSql;

	@Value("${override.msl.attributeList}")
	private String mslOverrideAttributeList;

	@Value("${attribution.getRunTypeFromSecID.sql}")
	private String runTypeFromSecID;

	@Value("${override.getSourceName.sql}")
	private String getSourceNameSql;

	@Value("${override.mslSetModified.sql}")
	private String setMSLModifiedSql;

	@Value("${override.mslSetReady.sql}")
	private String setMSLReadySql;

	@Value("${override.insert.identifier.sql}")
	private String insertIdentifierSP;

	@Value("${override.update.attribute.sql}")
	private String updateAttributeOverrideSP;

	@Value("${attribution.create.bankLoanUDI}")
	private String createBankLoanUDI;

	@Value("${attribution.create.CLOUDI}")
	private String createCLOUDI;

	@Value("${attribution.create.CDXUDI}")
	private String createCDXUDI;

	@Value("${attribution.create.TRSUDI}")
	private String createTRSUDI;

	@Value("${attribution.create.FWDUDI}")
	private String createFWDUDI;

	@Value("${attribution.update.udiState.sql}")
	private String setUDIReadySql;

	@Value("${attribution.udiSetDisabled.sql}")
	private String setUDIDisableSql;

	@Value("${attribution.udiSetModified.sql}")
	private String setUDIModifiedSql;

	@Value("${attribution.getSwapSMF}")
	private String getSwapSMF;

	@Value("${attribution.udiDeleteValues.sql}")
	private String deleteUDIValuesSql;

	@Value("${attribution.udiDelete.sql}")
	private String deleteUDISql;

	@Value("${attribution.getBBGSecMaster}")
	private String getBBGSecMaster;

	@Value("${attribution.getMarkitBL}")
	private String getMarkitBL;

	@Value("${attribution.list.uncovered.sql}")
	private String getUncoveredSql;

	@Value("${attribution.list.uncovered.fields.sql}")
	private String getUncoveredFieldsSql;

	@Value("${attribution.getPortfolioDetails.sql}")
	private String getUncoveredPortfolioDetails;

	@Value("${attribution.update.uncovered.fields.sql}")
	private String updateUncoveredFieldSql;

	@Value("${attribution.list.PathOpsCodeDesc1}")
	private String listPathOpsDesc1;

	@Value("${attribution.list.PathOpsCodeDesc2}")
	private String listPathOpsDesc2;

	@Value("${attribution.list.PathOpsCodeDesc3}")
	private String listPathOpsDesc3;

	@Value("${attribution.getPathOpsCodeDesc1.sql}")
	private String pathOpsDesc1;

	@Value("${attribution.getPathOpsCodeDesc2.sql}")
	private String pathOpsDesc2;

	@Value("${attribution.getPathOpsCodeDesc3.sql}")
	private String pathOpsDesc3;

	@Autowired
	public BaseService(@Qualifier("idaJdbcTemplate") JdbcTemplate idaJdbcTemplate,
			@Qualifier("lcapxPortfoliosJdbcTemplate") JdbcTemplate lcapxPortfoliosJdbcTemplate) {
		this.idaJdbcTemplate = idaJdbcTemplate;
		this.postgreidaJdbcTemplate = lcapxPortfoliosJdbcTemplate;
	}

	private BaseModel getDataFromDatasource(String datasource, String datasetName, Map<String, Object> params,
			String sql, String dbName, boolean returnResultLite) throws Exception {
		BaseModel rs = null;

		switch (datasource) {
		case "ida":
			rs = baseDAO.findUsingSQL(this.idaJdbcTemplate, params, sql, dbName, returnResultLite);
			break;

		default:
			throw new Exception("No Data source is configured for " + datasetName);
		}

		return rs;
	}

	public ResultLite getProcessRules(Map<String, Object> params) throws Exception {

		String sql = paramUtil.addSearchCriteriaFromRequestParametersToSql(this.processRulesSql, params,
				ParamUtil.requestParameterToColumnMap);
		params.clear();
		return (ResultLite) getDataFromDatasource("ida", "ProcessRules", params, sql, "ATTR", true);

	}

	public ResultLite getActiveAccounts(Map<String, Object> params) throws Exception {
		String sql = "select pvw.Name, pvW.NspAccountID,pvw.Symbol, act.*, runT.Type, runT.TypeDesc from attr.ingen.ActiveAccounts act "
				+ "join Attr.ingen.RunType runT on runT.RunTypeID = act.RunTypeID "
				+ "join Idap.lookup.PortfoliosVW pvw on " + "act.Portfolio_ID = pvw.PortfolioID";

		Map<String, String> paramMap = new ConcurrentHashMap<String, String>();
		paramMap.put("TargetSystem", "act.TargetSystem");
		sql = paramUtil.addSearchCriteriaFromRequestParametersToSql(sql, params, paramMap);
		params.clear();
		return (ResultLite) getDataFromDatasource("ida", "RequestTracker", params, sql, "ATTR", true);

	}

	public ResultLite disableActiveAccounts(Map<String, Object> params) throws Exception {

		String portfolio = (String) params.get("portfolio");
		String target = (String) params.get("TargetSystem");
		String[] accounts = portfolio.split(",");
		portfolio = "";
		for (String account : accounts) {
			portfolio = portfolio + "'" + account + "',";
		}
		portfolio = portfolio.substring(0, portfolio.length() - 1);

		if (portfolio.length() > 0) {

			String deleteSql = "update attr.ingen.ActiveAccounts set Active = 'N' where Portfolio in(" + portfolio
					+ ") and TargetSystem = '" + target + "';SELECT @@ROWCOUNT;";

			params.clear();
			ResultLite ans = (ResultLite) getDataFromDatasource("ida", "Portfolios_Info", params, deleteSql, "ATTR",
					true);
			if (ans.getData().get(0).get(0).equals(0)) {
				throw new Exception("No rows with Portfolio of: ");
			}
			return (new InfoModel("Portfolios were succesfully disabled"));
		} else {
			throw new Exception("No Portolios to disable");
		}

	}

	public Map<String, Object> enableActiveAccounts(Map<String, Object> params) throws Exception {

		String portfolio = (String) params.get("portfolio");
		String target = (String) params.get("TargetSystem");
		String[] accounts = portfolio.split(",");
		portfolio = "";
		for (String account : accounts) {
			portfolio = portfolio + "'" + account + "',";
		}
		portfolio = portfolio.substring(0, portfolio.length() - 1);
		if (portfolio.length() > 0) {

			String enableSql = "update attr.ingen.ActiveAccounts set Active = 'Y' where Portfolio in(" + portfolio
					+ ") and TargetSystem = '" + target + "';SELECT @@ROWCOUNT;";

			params.clear();
			ResultLite ans = (ResultLite) getDataFromDatasource("ida", "Portfolios_Info", params, enableSql, "ATTR",
					true);

			Map<String, Object> response = new ConcurrentHashMap<String, Object>();
			if (ans.getData().get(0).get(0).equals(0)) {

				response.put("data", "No rows with PortfolioId of: ");
				return response;
			}
			response.put("data", "Portfolios were succesfully enabled");
			return response;
		} else {
			throw new Exception("No Portolios provided");
		}

	}

	private void resolvePortfolioIDUsingSymbol(Map<String, Object> params) throws Exception {
		String portIdsql = "select PortfolioID from idap.lookup.PortfoliosVW where symbol = :symbol";
		ConcurrentHashMap<String, Object> params2 = new ConcurrentHashMap<String, Object>();
		params2.put("symbol", params.get("Portfolio"));

		ResultLite ans2 = (ResultLite) getDataFromDatasource("ida", "Portfolios_Info", params2, portIdsql, "ATTR",
				true);

		int portId = ((BigDecimal) ans2.getData().get(0).get(0)).intValue();
		params.put("Portfolio_ID", Integer.toString(portId));

		String acctName = (String) params.remove("AccountName");
		params.remove("Portfolio");

		params.put("Portfolio", acctName);
	}

	private void resolveRunTypetoID(Map<String, Object> params) throws Exception {
		String runType = (String) params.get("RunType");
		String targetSystem = (String) params.get("TargetSystem");

		String runTypIDSql = "Select RunTypeID from attr.ingen.RunType where TargetSystem = :targetsys and Type=:type";

		Map<String, Object> params2 = new ConcurrentHashMap<String, Object>();

		params2.put("targetsys", targetSystem);
		params2.put("type", runType);
		ResultLite runans = (ResultLite) getDataFromDatasource("ida", "Portfolios_Info", params2, runTypIDSql, "ATTR",
				true);

		int runtypeId = ((BigDecimal) runans.getData().get(0).get(0)).intValue();

		params.remove("RunType");
		params.put("RunTypeID", Integer.toString(runtypeId));
	}

	private Map<String, Object> jsonStringtoParamMap(String json) throws Exception {
		JSONObject jsonObj = new JSONObject(json);
		JSONArray names = jsonObj.names();

		Map<String, Object> params = new ConcurrentHashMap<String, Object>();

		for (int i = 0; i < names.length(); i++) {
			if (!(jsonObj.getString(names.getString(i)).equals(""))) {
				params.put(names.getString(i), jsonObj.getString(names.getString(i)));
			}
		}
		return params;
	}

	public Map<String, Object> addActiveAccount(HttpServletRequest request) throws Exception {
		String json = request.getReader().lines().collect(Collectors.joining());

		Map<String, Object> params = jsonStringtoParamMap(json);
		resolvePortfolioIDUsingSymbol(params);

		resolveRunTypetoID(params);

		String insertSql = "INSERT INTO ATTR.Ingen.ActiveAccounts ( ";
		String valuesSql = "VALUES ( ";
		for (Entry<String, Object> entry : params.entrySet()) {
			insertSql = insertSql + entry.getKey() + ", ";
			valuesSql = valuesSql + ":" + entry.getKey() + ", ";
		}
		insertSql = insertSql + "CreatedDTTM)";
		valuesSql = valuesSql + "getdate())";

		String sql = insertSql + valuesSql + "; SELECT @@ROWCOUNT;";

		ResultLite ans = (ResultLite) getDataFromDatasource("ida", "Portfolios_Info", params, sql, "ATTR", true);

		if (ans.getData().get(0).get(0).equals(0)) {
			throw new Exception("insertion of values " + params + " into ActiveAccounts has failed");
		}
		Map<String, Object> successmsg = new ConcurrentHashMap<String, Object>();
		successmsg.put("data", "Account was succesfully added");
		return successmsg;

	}

	public Map<String, Object> addRunType(HttpServletRequest request) throws Exception {
		String json = request.getReader().lines().collect(Collectors.joining());

		Map<String, Object> params = jsonStringtoParamMap(json);

		String insertSql = "INSERT INTO ATTR.Ingen.RunType ( ";
		String valuesSql = "VALUES ( ";
		for (Entry<String, Object> entry : params.entrySet()) {
			insertSql = insertSql + entry.getKey() + ", ";
			valuesSql = valuesSql + ":" + entry.getKey() + ", ";
		}
		insertSql = insertSql.substring(0, insertSql.length() - 2);
		insertSql = insertSql + ") ";
		valuesSql = valuesSql.substring(0, valuesSql.length() - 2);
		valuesSql = valuesSql + ")";

		String sql = insertSql + valuesSql + "; SELECT @@ROWCOUNT;";

		ResultLite ans = (ResultLite) getDataFromDatasource("ida", "Portfolios_Info", params, sql, "ATTR", true);

		if (ans.getData().get(0).get(0).equals(0)) {
			throw new Exception("insertion of values " + params + " into RunTypes has failed");
		}
		Map<String, Object> successmsg = new ConcurrentHashMap<String, Object>();
		successmsg.put("data", "RunTypes was succesfully added");
		return successmsg;

	}

	public List<Map<String, String>> searchRunType(Map<String, Object> params) throws Exception {

		String Sql = "select Type from attr.Ingen.RunType where TargetSystem=:targsys";

		ConcurrentHashMap<String, Object> params2 = new ConcurrentHashMap<String, Object>();
		params2.put("targsys", params.get("TargetSystem"));

		ResultLite ans = (ResultLite) getDataFromDatasource("ida", "Portfolios_Info", params2, Sql, "ATTR", true);

		List<Map<String, String>> data = new LinkedList<Map<String, String>>();

		for (List<Object> row : ans.getData()) {
			ConcurrentHashMap<String, String> runType = new ConcurrentHashMap<String, String>();

			runType.put("value", (String) row.get(0));
			runType.put("label", (String) row.get(0));
			data.add(runType);

		}

		return data;

	}

	public ResultLite getRunType(Map<String, Object> params) throws Exception {

		String Sql = "select * from attr.Ingen.RunType";

		ConcurrentHashMap<String, Object> params2 = new ConcurrentHashMap<String, Object>();

		ResultLite ans = (ResultLite) getDataFromDatasource("ida", "Portfolios_Info", params2, Sql, "ATTR", true);

		return ans;

	}

	public InfoModel deleteRunType(HttpServletRequest request) throws Exception {

		Map<String, Object> reqparams = paramUtil.getUiParams(request);

		String runTypeIds = (String) reqparams.get("runTypeID");

		if (runTypeIds.length() > 0) {

			String deleteSql = "Delete from ATTR.INGEN.RunType where RunTypeID in (" + runTypeIds
					+ ");SELECT @@ROWCOUNT;";

			Map<String, Object> params = new ConcurrentHashMap<String, Object>();
			ResultLite ans = (ResultLite) getDataFromDatasource("ida", "Portfolios_Info", params, deleteSql, "ATTR",
					true);
			if (ans.getData().get(0).get(0).equals(0)) {
				throw new Exception("No rows with RunTypeID of: ");
			}
			return (new InfoModel("RunType was succesfully deleted"));
		} else {
			throw new Exception("no RunTypes provided for delete");
		}

	}

	public ResultLite getUDIList(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;

		String sql = paramUtil.addSearchCriteriaFromRequestParametersToSql(this.getUDIListSql, params,
				new ConcurrentHashMap<String, String>());

		params.clear();
		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, sql, null,
				returnResultLite);
		return result;

	}

	public ResultLite getMSList(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;

		String sql = paramUtil.addSearchCriteriaFromRequestParametersToSql(this.getMSListSql, params,
				ParamUtil.requestParameterToColumnMap);

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, sql, null,
				returnResultLite);
		return result;
	}

	public ResultLite getMSListKeyValue(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;

		String sql = paramUtil.addSearchCriteriaFromRequestParametersToSql(this.getMSListKeyValueSql, params,
				ParamUtil.requestParameterToColumnMap);

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, sql, null,
				returnResultLite);
		return result;
	}

	public ResultLite getMslSearch(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;

		// String sql =
		// paramUtil.addSearchCriteriaFromRequestParametersToSql(this.getMslSearchSql,
		// params);
		// LOGGER.info("search resultsql: " + sql);
		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, getMslSearchSql, null,
				returnResultLite);

		return result;
	}

	@SuppressWarnings("unchecked")
	public void handleInsertUpdatePortfolio(HttpServletRequest request) throws Exception {
		boolean returnResultLite = true;

		Map<String, Object> params = paramUtil.getMapFromRequestJson(request);

		Map<String, Object> Identifiers = (Map<String, Object>) params.get("Identifiers");

		List<Map<String, Object>> Attributes = (List<Map<String, Object>>) params.get("Attributes");
		String portfolioType = (String) params.get("Type");

		params.clear();
		StringBuilder sqlIDArray = getIDsForPortfolioInsertUpdateProc(Identifiers);

		StringBuilder sqlAttributeArray = getAttributesForPortfolioInsertUpdatProc(Attributes);

		StringBuilder sqlInsertUpdateProc = buildInsertUpdateProcForPortfolios(portfolioType, sqlIDArray,
				sqlAttributeArray);
		
		LOGGER.info("insertion/update of portfolio using: \r\n" + sqlInsertUpdateProc.toString());

		baseDAO.updateUsingSql(this.postgreidaJdbcTemplate, params, sqlInsertUpdateProc.toString(), null,
				returnResultLite);
		
		LOGGER.info("insertion/update is successful");
	}

	private StringBuilder buildInsertUpdateProcForPortfolios(String portfolioType, StringBuilder sqlIDArray,
			StringBuilder sqlAttributeArray) {
		StringBuilder sqlInsertUpdateProc = new StringBuilder("set search_path to portfolio;\r\n" + "do $$\r\n"
				+ "declare\r\n" + "    l_msg   varchar(500);\r\n" + "    retval  boolean;\r\n" + "begin\r\n"
				+ "    select 'Processing start.....' into l_msg;\r\n" +

				"    select sp_load_portfolio\r\n" + "        (\r\n" +

				"              '");
		sqlInsertUpdateProc.append(portfolioType + "'\r\n");

		sqlInsertUpdateProc.append("              , array[\r\n");

		sqlInsertUpdateProc.append(sqlIDArray.toString());

		sqlInsertUpdateProc.append(" ]\r\n" +

				"            , array[\r\n");

		sqlInsertUpdateProc.append(sqlAttributeArray.toString());

		sqlInsertUpdateProc.append("]\r\n" +

				"            , null \r\n" +

				"            , null\r\n" + "        ) into retval;\r\n"
				+ "    raise notice 'Procedure Status: %', retval;\r\n" + "end\r\n" + "$$ language 'plpgsql';");
		return sqlInsertUpdateProc;
	}

	private StringBuilder getIDsForPortfolioInsertUpdateProc(Map<String, Object> Identifiers) {
		StringBuilder sqlIDArray = new StringBuilder();

		for (Entry<String, Object> identifier : Identifiers.entrySet()) {
			sqlIDArray.append("              cast(row('" + identifier.getKey() + "', '" + identifier.getValue()
					+ "') as ty_identifiers_kv),\r\n");
		}

		sqlIDArray.setLength(sqlIDArray.length() - 3);
		return sqlIDArray;
	}

	private StringBuilder getAttributesForPortfolioInsertUpdatProc(List<Map<String, Object>> Attributes) {
		StringBuilder sqlAttributeArray = new StringBuilder();
		for (Map<String, Object> attribute : Attributes) {
			sqlAttributeArray.append(
					"              cast(row('" + attribute.get("source") + "', '" + attribute.get("Portfolio Attribute")
							+ "', '" + attribute.get("Value") + "') as attributes_with_source_kv),\r\n");
		}

		sqlAttributeArray.setLength(sqlAttributeArray.length() - 3);
		return sqlAttributeArray;
	}

	public ResultLite getMslAttributeOverrides(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;
		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params,
				this.mslOverrideAttributeList, null, returnResultLite);
		return result;
	}

	public ResultLite setMslReady(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;
		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.setMSLReadySql, null,
				returnResultLite);
		return result;
	}

	public Map<String, Object> updateMSLAttributeOverride(HttpServletRequest request) throws Exception {
		String json = request.getReader().lines().collect(Collectors.joining());
		JSONObject jsonObj = new JSONObject(json);
		JSONArray names = jsonObj.names();

		Map<String, Object> params = new ConcurrentHashMap<String, Object>();

		for (int i = 0; i < names.length(); i++) {
			if (!(jsonObj.getString(names.getString(i)).equals(""))) {
				params.put(names.getString(i), jsonObj.getString(names.getString(i)));
			}
		}

		Map<String, Object> mslModifyParams = new ConcurrentHashMap<String, Object>();

		mslModifyParams.put("source_id", params.get("sourceId"));

		String sourceSql = this.getSourceNameSql;

		ResultLite srcans = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, mslModifyParams, sourceSql, "IDAP",
				true);

		String targetSystem = srcans.getData().get(0).get(0).toString();

		mslModifyParams.clear();

		mslModifyParams.put("Identifier", params.get("instrumentName"));
		mslModifyParams.put("TargetSystem", targetSystem);

		ResultLite mslidans = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, mslModifyParams,
				this.getMslSearchSql, "IDAP", true);

		int mslid = (Integer) mslidans.getData().get(0).get(0);

		String mslModfifiedSql = this.setMSLModifiedSql;
		mslModifyParams.clear();

		mslModifyParams.put("msl_id", Integer.toString(mslid));

		baseDAO.findUsingSQL(this.idaJdbcTemplate, mslModifyParams, mslModfifiedSql, "IDAP", true);

		Map<String, Object> params2 = new ConcurrentHashMap<String, Object>();

		params2.put("identifier", params.remove("instrumentName"));
		params2.put("source_id", params.get("sourceId"));
		params2.put("userId", params.get("userId"));

		ResultLite ans = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params2, this.insertIdentifierSP,
				"IDAP", true);

		String instId = ans.getData().get(0).get(0).toString();

		params.put("instrumentId", instId);

		Map<String, Object> result = baseDAO.updateOverride(this.updateAttributeOverrideSP, this.idaJdbcTemplate,
				params);

		return result;
	}

	private Date fiveDaysAgo(String date) throws Exception {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		cal.setTime(sdf.parse(date));
		cal.add(Calendar.DATE, -5);
		return cal.getTime();
	}

	private String getRecentDateString(String date) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		return dateFormat.format(fiveDaysAgo(date));
	}

	private String getUDISQL(String UDIType) throws Exception {
		String UDISql;
		switch (UDIType) {
		case "BankLoan":
			UDISql = this.createBankLoanUDI;
			break;
		case "Bridge Loan":
			UDISql = this.createBankLoanUDI;
			break;
		case "BridgeLoan":
			UDISql = this.createBankLoanUDI;
			break;
		case "Bank Loan":
			UDISql = this.createBankLoanUDI;
			break;
		case "CLO":
			UDISql = this.createCLOUDI;
			break;
		case "CMBX Swap":
			UDISql = this.createCDXUDI;
			break;
		case "CDX":
			UDISql = this.createCDXUDI;
			break;
		case "Total Return Swap":
			UDISql = this.createTRSUDI;
			break;
		case "Forwards":
			UDISql = this.createFWDUDI;
			break;
		default:
			Exception e = new Exception("Unable to make UDI for type " + UDIType);
			throw e;
		}
		return UDISql;
	}

	public ResultLite createUDI(Map<String, Object> params) throws Exception {

		String UDISql = "";

		String UDIType = "";

		UDIType = (String) params.remove("UDIType");

		switch (UDIType) {
		case "BL":
			UDISql = this.createBankLoanUDI;
			break;
		case "CLO":
			UDISql = this.createCLOUDI;
			break;
		case "CDX":
			UDISql = this.createCDXUDI;
			break;
		case "TRS":
			UDISql = this.createTRSUDI;
			break;
		case "FWD":
			UDISql = this.createFWDUDI;
			break;
		default:
			Exception e = new Exception("Unable to make UDI for type " + UDIType);
			throw e;
		}

		boolean returnResultLite = true;
		Map<String, Object> emptyparams = new ConcurrentHashMap<String, Object>();

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, emptyparams, UDISql, null,
				returnResultLite);

		String sql = (String) result.getData().get(0).get(0);

		ResultLite result2 = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, sql, "ATTR",
				returnResultLite);

		return result2;
	}

	private Map<String, String> getUDITypeandDate(String security, Map<String, Object> params) throws Exception {

		String UDIType = "";
		Map<String, Object> params2 = new ConcurrentHashMap<String, Object>();

		params2.put("Identifier", security);
		params2.put("TargetSystem", params.get("TargetSystem"));

		String infosql = getMslSearchSql.replaceFirst("\\*", " path_ops_code_desc_3,asof_dt_recent");
		ResultLite result1 = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params2, infosql, null, true);

		if (result1.getData().size() == 0) {
			throw new Exception("Security: " + security + " not found in msl");
		}

		UDIType = (String) result1.getData().get(0).get(0);
		String dateRecent = (String) result1.getData().get(0).get(1);

		Map<String, String> result = new HashMap<String, String>();

		result.put("UDIType", UDIType);
		result.put("dateRecent", dateRecent);
		return result;
	}

	private void createUDIfromBatch(String sql, Map<String, Object> params, String dateStart, String dateRecent,
			String security, String runType) throws Exception {
		Map<String, Object> udiParams = new ConcurrentHashMap<String, Object>();

		udiParams.put("TargetSystem", params.get("TargetSystem"));
		udiParams.put("startDate", dateStart);
		udiParams.put("endDate", dateRecent);
		udiParams.put("securityID", security);
		udiParams.put("runType", runType);

		ResultLite result2 = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, udiParams, sql, "ATTR", true);
		if (result2.getData().size() == 0) {
			throw new Exception("Security: " + security + " udi creation fail");
		}
	}

	private String getUDIRunType(String security, String dateRecent, Map<String, Object> params) throws Exception {
		Map<String, Object> runtypeparams = new ConcurrentHashMap<String, Object>();
		runtypeparams.put("securityID", security);
		runtypeparams.put("asofdate", dateRecent);
		runtypeparams.put("TargetSystem", params.get("TargetSystem"));

		ResultLite runtyperesult = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, runtypeparams,
				runTypeFromSecID, null, true);

		String runType = (String) runtyperesult.getData().get(0).get(0);
		return runType;
	}

	public Map<String, List<String>> batchCreateUDI(Map<String, Object> params) throws Exception {

		String securityIds = (String) params.get("securityID");

		String[] securityIDArr = securityIds.split(",");
		boolean returnResultLite = true;

		List<String> fails = new LinkedList<String>();
		List<String> success = new LinkedList<String>();

		for (String security : securityIDArr) {
			String UDISQLName = "";
			Map<String, String> udiInfo = null;
			try {
				udiInfo = getUDITypeandDate(security, params);
			} catch (Exception e) {
				if (e.getMessage().contains("not found in msl")) {
					fails.add(security);
					continue;
				} else {
					throw e;
				}
			}

			String UDIType = udiInfo.get("UDIType");
			String dateRecent = udiInfo.get("dateRecent");

			try {

				UDISQLName = getUDISQL(UDIType);
			} catch (Exception e) {
				if (e.getMessage().contains("Unable to make UDI for type")) {
					fails.add(security);
					continue;
				} else {
					throw e;
				}
			}

			udiInfo = null;
			String dateStart = getRecentDateString(dateRecent);

			String runType = getUDIRunType(security, dateRecent, params);

			Map<String, Object> emptyparams = new ConcurrentHashMap<String, Object>();

			ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, emptyparams, UDISQLName, null,
					returnResultLite);

			String udiCreateSQL = (String) result.getData().get(0).get(0);

			try {

				createUDIfromBatch(udiCreateSQL, params, dateStart, dateRecent, security, runType);
			} catch (Exception e) {
				if (e.getMessage().contains("udi creation fail")) {
					fails.add(security);
					continue;
				} else {
					throw e;
				}
			}
			success.add(security);

		}

		Map<String, List<String>> resultMap = new ConcurrentHashMap<String, List<String>>();
		resultMap.put("success", success);
		resultMap.put("fails", fails);
		return resultMap;
	}

	public ResultLite getSecuritySMF(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;
		Map<String, Object> detailParams = new ConcurrentHashMap<String, Object>();

		String sql = null;
		String PathOps2 = (String) params.remove("PathOpsCodeDesc2");
		String PathOps3 = (String) params.remove("PathOpsCodeDesc3");

		if (PathOps2.equals("Swaps")) {
			sql = this.getSwapSMF;
		} else if (PathOps3.equals("Bank Loan") || PathOps3.equals("Bridge Loan")) {
			sql = this.getMarkitBL;
		} else {
			sql = this.getBBGSecMaster;
		}

		detailParams.put("securityID", params.remove("securityID"));
		detailParams.put("asofdate", params.remove("asofdate"));
		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, sql, null,
				returnResultLite);

		String detailSql = (String) result.getData().get(0).get(0);

		ResultLite result2 = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, detailParams, detailSql, null,
				returnResultLite);

		return result2;
	}

	public ResultLite getUncoveredSecurities(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;
		Map<String, Object> emptyparams = new ConcurrentHashMap<String, Object>();

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, emptyparams, this.getUncoveredSql,
				null, returnResultLite);

		String uncovSqlRule = (String) result.getData().get(0).get(0);

		if (params.get("PathOpsCodeDesc1").equals("All")) {
			params.remove("PathOpsCodeDesc1");
		}
		if (params.get("PathOpsCodeDesc2").equals("All")) {
			params.remove("PathOpsCodeDesc2");
		}
		if (params.get("PathOpsCodeDesc3").equals("All")) {
			params.remove("PathOpsCodeDesc3");
		}

		emptyparams.put("TargetSystem", params.remove("TargetSystem"));
		emptyparams.put("startDate", params.remove("startDate"));
		emptyparams.put("endDate", params.remove("endDate"));

		String sql = paramUtil.addSearchCriteriaFromRequestParametersToSql(uncovSqlRule, params,
				ParamUtil.requestParameterToColumnMap);

		sql = sql + " Order By " + " State desc " + ", PathOpsCodeDesc3 " + " ,  PathOpsCodeDesc2 "
				+ " ,  PathOpsCodeDesc1 " + ",  SecurityID " + "Option(ReCompile);" + "Drop Table #L_Portfolios;"
				+ "Drop Table #UDICandidates;" + "Drop Table #temp_cps_table;";

		ResultLite result2 = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, emptyparams, sql, null,
				returnResultLite);

		return result2;
	}

	public ResultLite getUncoveredPortfolioDetails(Map<String, Object> params) throws Exception {

		boolean returnResultLite = true;
		Map<String, Object> emptyparams = new ConcurrentHashMap<String, Object>();

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, emptyparams,
				this.getUncoveredPortfolioDetails, null, returnResultLite);

		String sql = (String) result.getData().get(0).get(0);

		ResultLite result2 = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, sql, null,
				returnResultLite);

		return result2;
	}

	public ResultLite getUncoveredSecuritiyFields(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;
		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.getUncoveredFieldsSql,
				null, returnResultLite);
		return result;
	}

	public ResultLite updateUncoveredSecurityFields(HttpServletRequest request) throws Exception {
		boolean returnResultLite = true;
		String json = request.getReader().lines().collect(Collectors.joining());
		JSONObject jsonObj = new JSONObject(json);
		JSONArray names = jsonObj.names();

		Map<String, Object> params = new ConcurrentHashMap<String, Object>();

		for (int i = 0; i < names.length(); i++) {
			if (!(jsonObj.getString(names.getString(i)).equals(""))) {
				params.put(names.getString(i), jsonObj.getString(names.getString(i)));
			}
		}
		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params,
				this.updateUncoveredFieldSql, null, returnResultLite);

		setUDIModified((String) params.get("UDIID"));

		return result;
	}

	public ResultLite setUDIModified(String UDIID) throws Exception {
		Map<String, Object> params = new ConcurrentHashMap<String, Object>();
		params.put("UDIID", UDIID);

		boolean returnResultLite = true;
		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.setUDIModifiedSql,
				null, returnResultLite);
		return result;
	}

	public ResultLite setUDIReady(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;
		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.setUDIReadySql, null,
				returnResultLite);
		return result;
	}

	public ResultLite setUDIDisabled(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;
		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.setUDIDisableSql, null,
				returnResultLite);
		return result;
	}

	public String deleteUDI(Map<String, Object> params) throws Exception {

		String UDIIDCSVList = (String) params.remove("UDIID");

		String[] UDIIDList = UDIIDCSVList.split(",");

		boolean returnResultLite = true;

		for (String UDIID : UDIIDList) {
			params.put("UDIID", UDIID);
			baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.deleteUDIValuesSql, null, returnResultLite);

			baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.deleteUDISql, null, returnResultLite);
			params.clear();
		}
		return "success";

	}

	public ResultLite getPathOpsDesc1(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.listPathOpsDesc1, null,
				returnResultLite);
		return result;
	}

	public ResultLite getPathOpsDesc2(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.listPathOpsDesc2, null,
				returnResultLite);
		return result;
	}

	public ResultLite getPathOpsDesc3(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.listPathOpsDesc3, null,
				returnResultLite);
		return result;
	}

	public ResultLite pathOpsDesc1(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.pathOpsDesc1, null,
				returnResultLite);
		return result;
	}

	public ResultLite pathOpsDesc2(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.pathOpsDesc2, null,
				returnResultLite);
		return result;
	}

	public ResultLite pathOpsDesc3(Map<String, Object> params) throws Exception {
		boolean returnResultLite = true;

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.pathOpsDesc3, null,
				returnResultLite);
		return result;
	}

	public void emailReportListLoaded(String e) throws Exception {
		Properties props = new Properties();

		Session session = Session.getDefaultInstance(props, null);

		MimeMessage message = new MimeMessage(session);
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String asatdate = dateFormat.format(date);
		message.setFrom(new InternetAddress("doNotReply@FSLoader.com", "NoReply FactSet Loader"));
		message.addRecipient(Message.RecipientType.TO, new InternetAddress(attrSendEmail));
		message.setSubject("Error with FactSet Load asof " + asatdate);
		StringWriter sw = new StringWriter();

		String msg = e;
		message.setText(msg);

		Transport.send(message);
	}

	private Date yesterday() {
		final Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		return cal.getTime();
	}

	private String getYesterdayDateString() {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		return dateFormat.format(yesterday());
	}

}
