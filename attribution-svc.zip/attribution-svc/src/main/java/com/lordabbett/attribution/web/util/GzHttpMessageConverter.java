package com.lordabbett.attribution.web.util;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.converter.AbstractHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.http.server.ServerHttpResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SequenceWriter;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.lordabbett.attribution.base.model.BaseModel;
import com.lordabbett.attribution.base.model.ColumnMetaData;
import com.lordabbett.attribution.base.model.DataServiceException;
import com.lordabbett.attribution.base.model.ResultLite;

public class GzHttpMessageConverter extends AbstractHttpMessageConverter<BaseModel> {

	private static final Logger LOGGER = LoggerFactory.getLogger(GzHttpMessageConverter.class);

	public GzHttpMessageConverter() {
		super(new MediaType("application", "gz"));
	}

	@Override
	protected boolean supports(Class<?> clazz) {
		return BaseModel.class.isAssignableFrom(clazz);
	}

	@Override
	protected BaseModel readInternal(Class<? extends BaseModel> clazz, HttpInputMessage inputMessage)
			throws IOException, HttpMessageNotReadableException {
		return null;

	}

	@Override
	protected void writeInternal(BaseModel object, HttpOutputMessage outputMessage)
			throws IOException, HttpMessageNotWritableException {

		if (DataServiceException.class.isAssignableFrom(object.getClass())) {
			outputMessage.getHeaders().set("Content-Type", "application/json");
			OutputStream outputStream = outputMessage.getBody();
			DataServiceException exception = (DataServiceException) object;
			outputStream.write(String.valueOf(exception.getMessage()).getBytes());
			outputStream.close();
			return;
		}
		try {
			LOGGER.info("Streaming started");

			outputMessage.getHeaders().set("Content-Encoding", "gzip");

			if (object.getZipFormat().contains(".csv.gz")) {
				outputMessage.getHeaders().setContentDispositionFormData("attachment", object.getDatasetName()+".csv");
				outputMessage.getHeaders().setContentType(new MediaType("text","csv"));

				writeCsvZip(object, outputMessage);
			} else if (object.getZipFormat().contains(".json.gz") || object.getZipFormat().contains(".gz")) {
				outputMessage.getHeaders().setContentType(new MediaType("application","json"));
				writeJsonZip(object, outputMessage);
			} else {
				outputMessage.getHeaders().set(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);
				outputMessage.getHeaders().set(HttpHeaders.CONTENT_DISPOSITION, "inline");
				ServerHttpResponse servresp = (ServerHttpResponse) outputMessage;
				servresp.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
				OutputStream outputStream = outputMessage.getBody();
				outputStream.write(
						String.valueOf("Unable to provide zip in " + object.getZipFormat() + " format").getBytes());
				outputStream.close();
				throw new Exception("Unable to provide zip in " + object.getZipFormat() + " format");
			}

		} catch (Exception e) {
			LOGGER.error("failed to write in zip format", e);
		}

	}

	private void writeJsonZip(BaseModel object, HttpOutputMessage outputMessage) throws Exception {

		ResultLite result = (ResultLite) object;
		OutputStream outputStream = outputMessage.getBody();
		List<ColumnMetaData> columns = result.getColumns();

		ObjectMapper mapper = new ObjectMapper();

		GZIPOutputStream gzos = new GZIPOutputStream(outputStream);
		//gzos.write("{\"data\": [".getBytes());

		for (int j = 0; j < result.getData().size(); j++) {
			List<Object> row = result.getData().get(j);
			Map<String, Object> rowMap = new HashMap<>();

			for (int i = 0; i < columns.size(); ++i) {
				rowMap.put(columns.get(i).getName(), row.get(i));
			}
			if (j + 1 < result.getData().size()) {
				gzos.write(mapper.writeValueAsBytes(rowMap));
				gzos.write(",".getBytes());
			} else {
				gzos.write(mapper.writeValueAsBytes(rowMap));
			}
			rowMap.clear();
			row.clear();
			gzos.flush();
		}

		//gzos.write("]}".getBytes());

		gzos.flush();
		gzos.close();

		outputStream.flush();
		outputStream.close();

		LOGGER.info("successfully sent encoded json");
		return;

	}

	private void writeCsvZip(BaseModel object, HttpOutputMessage outputMessage) throws Exception {
		ResultLite result = (ResultLite) object;
		OutputStream outputStream = outputMessage.getBody();
		List<List<Object>> listOfMap = result.getData();
		List<ColumnMetaData> columns = result.getColumns();

		GZIPOutputStream gzos = new GZIPOutputStream(outputStream);

		CsvSchema schema = null;
		CsvSchema.Builder schemaBuilder = CsvSchema.builder();
		if (columns != null && !columns.isEmpty()) {
			for (ColumnMetaData col : columns) {
				schemaBuilder.addColumn(col.getName());
			}
			schema = schemaBuilder.build().withLineSeparator("\r\n").withHeader();
		}
		columns = null;
		CsvMapper mapper = new CsvMapper();
		SequenceWriter writer = mapper.writer(schema).writeValues(gzos);
		int i = 0;
		for (List<Object> list : listOfMap) {
			writer.write(list);
			list.clear();
			if (i++ % 5000 == 0) {
				gzos.flush();
			}
		}

		object = null;
		listOfMap = null;

		result = null;

		gzos.flush();
		gzos.close();

		outputStream.flush();
		outputStream.close();

		LOGGER.info("successfully sent encoded csv");
		return;

	}

}
