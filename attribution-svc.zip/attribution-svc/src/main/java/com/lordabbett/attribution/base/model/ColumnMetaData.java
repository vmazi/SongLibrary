package com.lordabbett.attribution.base.model;

public class ColumnMetaData extends BaseModel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8734588300069753170L;
	String name;
	String type;
	String value;
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	

}
