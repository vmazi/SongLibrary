package com.lordabbett.attribution.web.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.lordabbett.attribution.base.model.InfoModel;
import com.lordabbett.attribution.base.model.ResultLite;
import com.lordabbett.attribution.base.service.BaseService;
import com.lordabbett.attribution.base.service.FactSetAPIService;
import com.lordabbett.attribution.web.util.ParamUtil;

@CrossOrigin(origins = "*", maxAge = 3000)
@RestController
public class AttributionServiceController {
	@Autowired
	private BaseService baseService;

	@Autowired
	private FactSetAPIService fsApiService;

	@Autowired
	private ParamUtil paramUtil;

	@RequestMapping(value = "/activeAccounts*", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleActiveAccountsRequest(HttpServletRequest request) throws Exception {
		return baseService.getActiveAccounts(paramUtil.getUiParams(request));
	}

	@RequestMapping(value = "/disableAccounts*", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleDisableActiveAccountsRequest(HttpServletRequest request) throws Exception {
		return baseService.disableActiveAccounts(paramUtil.getUiParams(request));
	}

	@RequestMapping(value = "/enableAccounts*", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public Map<String, Object> handleEnableActiveAccountsRequest(HttpServletRequest request) throws Exception {
		return baseService.enableActiveAccounts(paramUtil.getUiParams(request));
	}

	@RequestMapping(value = "/addAccount*", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public Map<String, Object> handleAddActiveAccountsRequest(HttpServletRequest request) throws Exception {
		return baseService.addActiveAccount(request);
	}

	@RequestMapping(value = "/searchRunType*", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public List<Map<String, String>> handleRunTypeSearch(HttpServletRequest request) throws Exception {
		return baseService.searchRunType(paramUtil.getUiParams(request));
	}

	@RequestMapping(value = "/getRunTypes*", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleRunTypeGet(HttpServletRequest request) throws Exception {
		return baseService.getRunType(paramUtil.getUiParams(request));
	}

	@RequestMapping(value = "/addRunType*", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public Map<String, Object> handleRunTypeRequest(HttpServletRequest request) throws Exception {
		return baseService.addRunType(request);
	}

	@RequestMapping(value = "/deleteRunTypes*", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.OK)
	public InfoModel handleDeleteRunTypeRequest(HttpServletRequest request) throws Exception {
		return baseService.deleteRunType(request);
	}

	@RequestMapping(value = "/runCalc", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public void handleRunCalc(HttpServletRequest request) throws Exception {

		fsApiService.runDownload(paramUtil.getUiParams(request));
		// fsApiService.runCalc("LAHY", "MLHUC0","20190308","20190311");
	}

	@RequestMapping(value = "/getComponents", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public void handleGetComponents(HttpServletRequest request) throws Exception {

		// fsApiService.runDownload("daily");
		fsApiService.getCompIds();
	}

	@RequestMapping(value = "/processRules", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleProcessRulesRequest(HttpServletRequest request) throws Exception {

		return baseService.getProcessRules(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/overrides/getUDIList", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleGetUDIList(HttpServletRequest request) throws Exception {
		return baseService.getUDIList(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/msl_static", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleGetMSList(HttpServletRequest request) throws Exception {
		return baseService.getMSList(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/msl_static_values", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleGetMSListKeyValue(HttpServletRequest request) throws Exception {
		return baseService.getMSListKeyValue(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/msl_search", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleMSLSearch(HttpServletRequest request) throws Exception {
		return baseService.getMslSearch(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/overrides/mslAttributeOverrides", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleMslAttributeOverrides(HttpServletRequest request) throws Exception {
		return baseService.getMslAttributeOverrides(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/overrides/mslAttributeUpdate", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)

	public Map<String, Object> handleMSLAttributeOverrideUpdateRequest(HttpServletRequest request) throws Exception {
		return baseService.updateMSLAttributeOverride(request);
	}

	@RequestMapping(value = "/overrides/mslReady", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleMslReady(HttpServletRequest request) throws Exception {
		return baseService.setMslReady(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/batchCreateUDI", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public Map<String, List<String>> handleBatchCreateUDIRequest(HttpServletRequest request) throws Exception {
		return baseService.batchCreateUDI(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/createUDI", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleCreateUDIRequest(HttpServletRequest request) throws Exception {
		return baseService.createUDI(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/setUDIReady", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleSetUDIReadyRequest(HttpServletRequest request) throws Exception {
		return baseService.setUDIReady(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/uncoveredSecurities", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleUncoveredSecuritiesRequest(HttpServletRequest request) throws Exception {
		return baseService.getUncoveredSecurities(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/uncoveredSecuritiesFields", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleUncoveredSecuritiesFieldsRequest(HttpServletRequest request) throws Exception {
		return baseService.getUncoveredSecuritiyFields(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/updateUncoveredSecuritiesFields", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleUpdateUncoveredSecuritiesFieldsRequest(HttpServletRequest request) throws Exception {
		return baseService.updateUncoveredSecurityFields(request);

	}

	@RequestMapping(value = "/attribution/getSecurityDetails", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleSecurityDetailsRequest(HttpServletRequest request) throws Exception {
		return baseService.getSecuritySMF(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/getPortfolioDetails", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handlePortfolioDetailsRequest(HttpServletRequest request) throws Exception {
		return baseService.getUncoveredPortfolioDetails(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/listPathOpsDesc1", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handlelistPathOpsDesc1Request(HttpServletRequest request) throws Exception {
		return baseService.getPathOpsDesc1(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/listPathOpsDesc2", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handlelistPathOpsDesc2Request(HttpServletRequest request) throws Exception {
		return baseService.getPathOpsDesc2(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/listPathOpsDesc3", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handlelistPathOpsDesc3Request(HttpServletRequest request) throws Exception {
		return baseService.getPathOpsDesc3(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/getPathOpsDesc1", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handlePathOpsDesc1Request(HttpServletRequest request) throws Exception {
		return baseService.pathOpsDesc1(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/getPathOpsDesc2", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handlePathOpsDesc2Request(HttpServletRequest request) throws Exception {
		return baseService.pathOpsDesc2(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/getPathOpsDesc3", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handlePathOpsDesc3Request(HttpServletRequest request) throws Exception {
		return baseService.pathOpsDesc3(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/disableUDI", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public ResultLite handleDisableUDIRequest(HttpServletRequest request) throws Exception {
		return baseService.setUDIDisabled(paramUtil.getUiParams(request));

	}

	@RequestMapping(value = "/attribution/deleteUDI", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.GET)
	@ResponseStatus(HttpStatus.OK)
	public String handleDeleteUDIRequest(HttpServletRequest request) throws Exception {
		return baseService.deleteUDI(paramUtil.getUiParams(request));

	}

	@CrossOrigin
	@RequestMapping(value = "/insertUpdatePortfolio", produces = { "application/json", "text/csv",
			"application/xml" }, method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.OK)
	public String handleInsertUpdatePortfolios(HttpServletRequest request) throws Exception {
		baseService.handleInsertUpdatePortfolio(request);
		return "finished";
	}

}
