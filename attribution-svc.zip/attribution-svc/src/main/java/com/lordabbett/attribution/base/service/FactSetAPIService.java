package com.lordabbett.attribution.base.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.concurrent.BasicThreadFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.factset.protobuf.stach.PackageProto.Package;
import com.factset.protobuf.stach.table.SeriesDataProto.SeriesData;
import com.factset.protobuf.stach.table.SeriesDefinitionProto.SeriesDefinition;
import com.factset.protobuf.stach.table.TableProto.Table;
import com.lordabbett.attribution.base.dao.BaseDAO;
import com.lordabbett.attribution.base.model.ResultLite;
import com.lordabbett.attribution.web.util.ParamUtil;

import factset.analyticsapi.paengineapi.v1.ApiClient;
import factset.analyticsapi.paengineapi.v1.ApiException;
import factset.analyticsapi.paengineapi.v1.ApiResponse;
import factset.analyticsapi.paengineapi.v1.api.CalculationsApi;
import factset.analyticsapi.paengineapi.v1.api.ComponentsApi;
import factset.analyticsapi.paengineapi.v1.models.CalculationParameters;
import factset.analyticsapi.paengineapi.v1.models.ComponentListEntity;
import factset.analyticsapi.paengineapi.v1.models.DateParameters;

@Service
public class FactSetAPIService {
	private static ApiClient apiClient = null;

	@Value("${fs.components.sql}")
	private String getComponentSql;

	@Value("${fs.documents.sql}")
	private String getDocumentsSql;

	@Value("${fs.updateComponents.sql}")
	private String updateComponentsSql;

	@Value("${fs.getRequestId.sql}")
	private String requestIDProc;

	@Value("${fs.createReportStatus.sql}")
	private String createReportStatus;

	@Value("${fs.getRunTypeID.sql}")
	private String getRunTypeId;

	@Value("${fs.updateReportStatus.sql}")
	private String updateReportStatus;

	@Value("${fs.findReportStatus.sql}")
	private String findReportStatus;

	@Value("${config.throttle.threads:20}")
	private int threadThrottle;

	private static ExecutorService executorService;

	protected JdbcTemplate idaJdbcTemplate;

	@Autowired
	protected BaseDAO baseDAO;

	@Autowired
	ParamUtil paramUtil;

	@Autowired
	FactSetLoadService fService;

	private Map<String, Object> repdefIds;

	private ArrayList<Integer> hyports;

	private ArrayList<Integer> emports;

	@Autowired
	KafkaService kafkaService;

	private static final Logger LOGGER = LoggerFactory.getLogger(FactSetAPIService.class);

	public static String portfolioMsgParam = "Portfolio";

	public static String benchmarkMsgParam = "Benchmark";
	public static String reportPeriodMsgParam = "ReportPeriod";

	public static String startDateMsgParam = "Startdate";
	public static String endDateMsgParam = "Enddate";
	public static String documentNameMsgParam = "Document_Name";
	public static String componentidMsgParam = "ComponentID";

	public static String attrRequestIdMsgParam = "AttrRequestID";

	@Autowired
	public FactSetAPIService(@Qualifier("idaJdbcTemplate") JdbcTemplate idaJdbcTemplate) {

		this.idaJdbcTemplate = idaJdbcTemplate;

	}

	@PostConstruct
	public void initFactSetAPIService() {
		try {
			this.repdefIds = this.loadRepDefIds();
			this.hyports = fService.listOfAccountsbyRunType("FS_HY_HLDG");
			this.emports = fService.listOfAccountsbyRunType("FS_EM_HLDG");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BasicThreadFactory threadFactory = new BasicThreadFactory.Builder()
				.namingPattern("ReportLoadingThread-%d-Batch-").build();
		executorService = Executors.newFixedThreadPool(threadThrottle, threadFactory);

	}

	public void runDownload(Map<String, Object> params) throws Exception {

		// Map<String, Object> params = new ConcurrentHashMap<String, Object>();

		String enddate = (String) params.remove("endDate");
		String startdate = (String) params.remove("startDate");
		String sql = paramUtil.addSearchCriteriaFromRequestParametersToSql(getComponentSql, params,
				ParamUtil.requestParameterToColumnMap);

		params.clear();
		ResultLite components = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, sql, "ATTR", true);

		for (List<Object> row : components.getData()) {
			String componentid = (String) row.get(0);
			String document_name = (String) row.get(1);
			String reportPeriod = (String) row.get(2);
			String portfolio = (String) row.get(3);
			String benchmark = (String) row.get(4);
			int attrRequestId = this.insertReportStatus(portfolio, benchmark, enddate, startdate, componentid,
					reportPeriod, document_name);

			if (attrRequestId != -1) {

				Map<String, String> payload = new HashMap<String, String>();

				payload.put(portfolioMsgParam, portfolio);
				payload.put(benchmarkMsgParam, benchmark);
				payload.put(startDateMsgParam, startdate);
				payload.put(endDateMsgParam, enddate);
				payload.put(reportPeriodMsgParam, reportPeriod);
				payload.put("ComponentID", componentid);
				payload.put("Document_Name", document_name);
				payload.put("AttrRequestID", Integer.toString(attrRequestId));

				kafkaService.sendMessage(payload);
			}

		}

		LOGGER.info("Sent Requests!");

	}

	protected void runReport(String portfolio, String benchmark, String startdate, String enddate, String reportPeriod,
			String componentid, String document_name, int attrRequestID) throws Exception {

		try {

			runCalc(portfolio, benchmark, startdate, enddate, reportPeriod, componentid, document_name, attrRequestID);
		} catch (Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace = sw.toString();
			updateReportStatus(attrRequestID, "Error", sStackTrace);
			throw e;

		}
	}

	private String reportNameToSheetName(String reportName) {

		if (reportName.length() > 30) {
			reportName = reportName.substring(0, 31);

		}
		reportName = reportName.replaceAll("/", " ");
		reportName = reportName.replaceAll(" ", "_");
		reportName = reportName + ".txt";
		return reportName;

	}

	public void getCompIds() throws Exception {

		this.repdefIds = this.loadRepDefIds();

		Map<String, Object> repdefids = this.repdefIds;

		Map<String, Object> params = new ConcurrentHashMap<String, Object>();
		ResultLite documents = (ResultLite) baseDAO.findUsingSQL(this.idaJdbcTemplate, params, this.getDocumentsSql,
				"ATTR", true);

		for (List<Object> row : documents.getData()) {

			String documentName = (String) row.get(0);
			String frequency = (String) row.get(1);
			String reportPeriod = "daily";
			int repdefid;
			String componentId = null;
			ComponentsApi componentsApi = new ComponentsApi(apiClientFactory());
			Map<String, ComponentListEntity> components = componentsApi.getAll(documentName);

			for (Entry<String, ComponentListEntity> component : components.entrySet()) {

				ComponentListEntity componentEntity = component.getValue();
				String reportName = componentEntity.getCategory().split(" / ")[1];

				reportName = reportNameToSheetName(reportName);
				if (repdefids.containsKey(reportName.toLowerCase())) {
					repdefid = (int) repdefids.get(reportName.toLowerCase());

				} else {
					continue;
				}

				if (reportName.toLowerCase().contains("mtd")) {
					reportPeriod = "mtd";
				} else if (reportName.toLowerCase().contains("ytd")) {
					reportPeriod = "ytd";
				} else if (reportName.toLowerCase().contains("mnth")) {
					reportPeriod = "monthly";
				} else if (reportName.toLowerCase().contains("wkly")) {
					reportPeriod = "weekly";
				}
				if (reportName.toLowerCase().contains("qtd")) {
					reportPeriod = "qtd";
				}

				componentId = component.getKey();

				Map<String, Object> params2 = new ConcurrentHashMap<String, Object>();

				params2.put("reportPeriod", reportPeriod);
				params2.put("reportDefId", Integer.toString(repdefid));
				params2.put("componentId", componentId);
				params2.put("frequency", frequency);
				params2.put("documentName", documentName);

				baseDAO.findUsingSQL(idaJdbcTemplate, params2, updateComponentsSql, null, true);
				params2.clear();

			}
		}

	}

	public int getRequestID(String TargetSystem, String RunType, String ParentRequestType) throws Exception {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		Date now = new Date();
		sdf.format(now);

		Map<String, Object> params = new ConcurrentHashMap<String, Object>();

		params.put("V_ParentRequestID", sdf.format(now));
		params.put("V_ParentRequestType", ParentRequestType);
		params.put("V_TargetSystem", TargetSystem);
		params.put("V_RunType", RunType);

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, requestIDProc, null, true);

		int requestID = (int) ((BigDecimal) result.getData().get(0).get(0)).intValue();

		return requestID;
	}

	private int getReportDefFromParams(String portfolio, String benchmark, String component_id,
			Map<String, Object> sqlparams) throws Exception {
		int repDefId = -1;
		String sql = "select report_definition_id from attr.factset.report_component where portfolio_name = :portfolio and benchmark_name = :benchmark and component_id = :component_id";

		sqlparams.put("portfolio", portfolio);
		sqlparams.put("benchmark", benchmark);
		sqlparams.put("component_id", component_id);

		ResultLite repdefresult = ((ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, sqlparams, sql, null, true));

		repDefId = (Integer) repdefresult.getData().get(0).get(0);
		return repDefId;
	}

	private int getRunTypeID(String runType, Map<String, Object> statusParams) throws Exception {

		statusParams.put("RunType", runType);

		ResultLite result = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, statusParams, getRunTypeId, null, true);

		int runtypeid = ((BigDecimal) result.getData().get(0).get(0)).intValue();
		return runtypeid;
	}

	private int insertReportStatus(String portfolio, String benchmark, String enddate, String startdate,
			String component_id, String reportPeriod, String document_name) throws Exception {
		String runType = "FS_BL_HLDG";
		int runtypeid = -1;

		Map<String, Object> sqlparams = new ConcurrentHashMap<String, Object>();

		int repDefId = getReportDefFromParams(portfolio, benchmark, component_id, sqlparams);

		Integer pid = fService.lookupPort(portfolio);

		if (hyports.contains(pid)) {
			runType = "FS_HY_HLDG";
		} else if (emports.contains(pid)) {
			runType = "FS_EM_HLDG";

		}

		Map<String, Object> statusParams = new ConcurrentHashMap<String, Object>();

		runtypeid = getRunTypeID(runType, statusParams);

		statusParams.clear();
		statusParams.put("Report_Period", reportPeriod);
		statusParams.put("Document_Name", document_name);

		statusParams.put("Report_Definition_id", Integer.toString(repDefId));
		statusParams.put("Portfolio", portfolio);
		statusParams.put("Benchmark", benchmark);

		statusParams.put("asofdate", enddate);

		statusParams.put("report_start_date", startdate);
		statusParams.put("report_end_date", enddate);

		ResultLite prevreports = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, statusParams, this.findReportStatus,
				null, true);

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String asatdate = dateFormat.format(date);

		if (prevreports.getData().isEmpty()) {

			int attrRequestId = getRequestID("FactSet", runType, "API");

			statusParams.put("State", "Initialized Request");
			statusParams.put("RequestID", Integer.toString(attrRequestId));
			statusParams.put("RunTypeID", Integer.toString(runtypeid));

			statusParams.put("asatdate", asatdate);

			baseDAO.findUsingSQL(idaJdbcTemplate, statusParams, this.createReportStatus, null, true);

			return attrRequestId;

		} else {
			return -1;
		}

	}

	public void updateReportStatus(int attrRequestID, String state, String message) throws Exception {

		Map<String, Object> statusParams = new ConcurrentHashMap<String, Object>();

		statusParams.put("RequestID", Integer.toString(attrRequestID));
		statusParams.put("state", state);
		statusParams.put("message", message);

		baseDAO.findUsingSQL(idaJdbcTemplate, statusParams, this.updateReportStatus, null, true);

	}

	private void loadReportWithThread(int attrRequestId, ApiResponse<Package> calculationResultResponse,
			String portfolio, String benchmark, String reportName, String reportPeriod, String startdate,
			String enddate, int repdefID) {

		executorService.submit(() -> {
			LOGGER.info("loading report with reqid: " + attrRequestId);

			String preprocfile;
			try {
				preprocfile = generatePreproc(calculationResultResponse, portfolio, benchmark, reportName, reportPeriod,
						startdate, enddate, "preprocjson" + attrRequestId + ".txt");
				this.updateReportStatus(attrRequestId, "Loading", "Loading into Reporting DB");
				loadPreProc(preprocfile, repdefID);
				this.updateReportStatus(attrRequestId, "Complete", "Succesfully loaded into Reporting DB");
			} catch (Exception e) {
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				String sStackTrace = sw.toString();
				try {
					updateReportStatus(attrRequestId, "Error", sStackTrace);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}

		});
	}

	public void runCalc(String portfolio, String benchmark, String startdate, String enddate, String reportPeriod,
			String componentId, String documentName, int attrRequestId) throws Exception {
		try {

			Map<String, Object> repdefids = this.repdefIds;

			ComponentsApi componentsApi = new ComponentsApi(apiClientFactory());
			Map<String, ComponentListEntity> components = componentsApi.getAll(documentName);

			// "D97F580B94482C66FFA0BEAE5D12ACB43740FFD545EECEC995EA5AAF9DD82A10";
			LOGGER.info("ComponentID: " + componentId);
			LOGGER.info("componentName: " + components.get(componentId).getCategory());

			String prereportName = components.get(componentId).getCategory().split(" / ")[1];

			String reportName = reportNameToSheetName(prereportName);
			LOGGER.info("reportSheetName: " + reportName.toLowerCase());

			int repdefID = (int) repdefids.get(reportName.toLowerCase());

			CalculationParameters parameters = new CalculationParameters();
			parameters.componentid(componentId);
			parameters.setAccount("CLIENT:/LA_PROD/" + portfolio + ".ACCT");

			parameters.setBenchmark(benchmark);

			DateParameters dates = new DateParameters();

			if (!reportName.toLowerCase().contains("characteristics")) {
				dates.setStartdate(startdate);

			}
			dates.setEnddate(enddate);

			parameters.setDates(dates);
			CalculationsApi calculationsApi = new CalculationsApi(apiClientFactory());
			ApiResponse<Void> calculationResult = (new CalculationsApi(apiClientFactory()))
					.createWithHttpInfo(parameters);

			Map<String, List<String>> headers = calculationResult.getHeaders();
			String locationToPoll = headers.get("Location").get(0);
			String[] splits = locationToPoll.split("/");
			String requestId = splits[splits.length - 1];

			ApiResponse<Void> calculationPollResponse = calculationsApi.getStatusByIdWithHttpInfo(requestId);

			this.updateReportStatus(attrRequestId, "Calculating", "Sent calculation request to FactSet");

			while (calculationPollResponse.getStatusCode() == 202) {
				List<String> progress = calculationPollResponse.getHeaders().get("X-Factset-Api-Pickup-Progress");
				if (progress != null) {
					LOGGER.info("Progress: " + progress.get(0));
				}

				List<String> cacheControl = calculationPollResponse.getHeaders().get("Cache-Control");
				if (cacheControl != null) {
					int maxAge = Integer.parseInt(cacheControl.get(0).replaceAll("max-age=", ""));
					LOGGER.info("Sleeping for: " + maxAge + " seconds");
					Thread.sleep(maxAge * 1000);
				} else {
					LOGGER.info("Sleeping for: 2 seconds");
					this.updateReportStatus(attrRequestId, "Polling", "Polling");

					Thread.sleep(2 * 1000);
				}

				calculationPollResponse = calculationsApi.getStatusByIdWithHttpInfo(requestId);
			}

			if (calculationPollResponse.getStatusCode() != 201) {
				System.err.println("Error!!!");
				System.err.println("X-DataDirect-Request-Key: "
						+ calculationPollResponse.getHeaders().get("X-DataDirect-Request-Key").get(0));
				return;
			}

			ApiResponse<com.factset.protobuf.stach.PackageProto.Package> calculationResultResponse = calculationsApi
					.getResultByIdWithHttpInfo(requestId);

			loadReportWithThread(attrRequestId, calculationResultResponse, portfolio, benchmark, reportName,
					reportPeriod, startdate, enddate, repdefID);

		} catch (ApiException e) {
			/*
			 * System.err.println("ResponseBody: " + e.getResponseBody());
			 * System.err.println( "X-DataDirect-Request-Key: " +
			 * e.getResponseHeaders().get("X-DataDirect-Request-Key").get(0));
			 * e.printStackTrace();
			 */
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String sStackTrace = sw.toString();

			this.updateReportStatus(attrRequestId, "API Error", sStackTrace);
		}
	}

	private void loadPreProc(String preprocpath, int repdefID) throws Exception {

		File file = new File(preprocpath);

		BufferedReader br2 = new BufferedReader(new FileReader(preprocpath));
		br2.readLine();
		String reportName = br2.readLine();
		br2.close();

		BufferedReader br = new BufferedReader(new FileReader(preprocpath));
		for (int i = 0; i < 2; i++) {
			br.readLine();
		}
		String repPeriod = br.readLine();
		br.close();
		if (reportName.toLowerCase().contains("perform")) {
			fService.loadFactsetReturns(file.getAbsolutePath(), repPeriod, hyports);
			if (!file.delete()) {
				file.deleteOnExit();
			}

		} else if (reportName.toLowerCase().contains("characteristics")) {
			fService.loadFactsetAnalytics(file.getAbsolutePath());
			if (!file.delete()) {
				file.deleteOnExit();
			}
		} else {
			int reportInstID = fService.generateReportInstance(file.getAbsolutePath(), repdefID, repPeriod, true);

			int activeReport = fService.getActiveReportFromFile(file.getAbsolutePath(), repdefID, repPeriod);

			fService.loadFactsetReportIntoDB(file.getAbsolutePath(), reportInstID, repdefID, repdefIds, repPeriod);
			if (activeReport != -1) {
				fService.inActivateReport(activeReport);
			}
			fService.activateReport(reportInstID);

			if (!file.delete()) {
				file.deleteOnExit();
			}
		}
	}

	@SuppressWarnings("deprecation")
	private String generatePreproc(
			ApiResponse<com.factset.protobuf.stach.PackageProto.Package> calculationResultResponse, String portfolio,
			String benchmark, String reportName, String reportPeriod, String startdate, String enddate,
			String preprocname) throws Exception {

		Map<String, Table> tables = calculationResultResponse.getData().getTables();

		/*
		 * BufferedWriter bw = new BufferedWriter(new
		 * FileWriter("preprocFromJsonUnproc.txt", false));
		 * 
		 * bw.write(calculationResultResponse.getData().toString());
		 * 
		 * bw.flush(); bw.close();
		 */

		BufferedWriter bw2 = new BufferedWriter(new FileWriter(preprocname + ".txt", false));
		File file = new File(preprocname + ".txt");

		putHeader(bw2, portfolio, benchmark, reportName, reportPeriod, startdate, enddate);
		boolean threeGroups = determineGroupLevels(calculationResultResponse);

		boolean noGroup = determineNoGroup(calculationResultResponse);

		writeRowByRow(tables, threeGroups, bw2, noGroup);
		bw2.write(";;;;;;;;;;;;;;;;");
		bw2.newLine();
		bw2.flush();
		bw2.close();
		LOGGER.info("preproc generated");
		return file.getAbsolutePath();
	}

	private void writeRowByRow(Map<String, Table> tables, boolean threeGroups, BufferedWriter bw2, boolean noGroup)
			throws Exception {
		@SuppressWarnings("deprecation")
		Object[] columnDatas = tables.entrySet().stream().findFirst().get().getValue().getData().getColumns().values()
				.toArray();

		SeriesData coldata1 = (SeriesData) columnDatas[1];

		Object[] vals = coldata1.getStringArray().getValuesList().toArray();

		int size = vals.length;
		for (int i = 0; i < size; i++) {

			writeThisRow(bw2, columnDatas, coldata1, threeGroups, vals, i, noGroup);

			bw2.newLine();
			if (i == 0) {
				bw2.write(";;;;;;;;;;;;;;;;");
				bw2.newLine();
			}
		}
	}

	private void writeThisRow(BufferedWriter bw2, Object[] columnDatas, SeriesData coldata1, boolean threeGroups,
			Object[] vals, int i, boolean noGroup) throws Exception {
		SeriesData coldata;
		for (int j = 0; j < columnDatas.length; j++) {
			coldata = (SeriesData) columnDatas[j];
			vals = coldata.getStringArray().getValuesList().toArray();
			if (vals.length == 0) {
				vals = coldata.getDoubleArray().getValuesList().toArray();
			}
			if (noGroup) {
				this.writeDataToFileForNoGroups(j, i, columnDatas, vals, coldata1, bw2);
			} else if (threeGroups) {
				writeDataToFileFor3Groups(j, i, columnDatas, vals, coldata1, bw2);
			} else {
				writeDataToFileFor2Groups(j, i, columnDatas, vals, coldata1, bw2);
			}
		}
	}

	private void writeDataToFileForNoGroups(int j, int i, Object[] columnDatas, Object[] vals, SeriesData coldata1,
			BufferedWriter bw2) throws Exception {

		if (vals[i].toString().equalsIgnoreCase("NaN")) {
			bw2.write("0;");
		} else {
			bw2.write(vals[i].toString() + ";");
		}

	}

	private void writeDataToFileFor2Groups(int j, int i, Object[] columnDatas, Object[] vals, SeriesData coldata1,
			BufferedWriter bw2) throws Exception {
		if (j == 0) {
			handleTreeWrite(columnDatas, vals, coldata1, bw2, i, j);

		} else if (j == 1) {
			if (!vals[i].toString().equalsIgnoreCase("null")) {
				bw2.write(vals[i].toString() + ";");
			}
		} else {
			if (vals[i].toString().equalsIgnoreCase("NaN")) {
				bw2.write("0;");
			} else {
				bw2.write(vals[i].toString() + ";");
			}
		}
	}

	private void writeDataToFileFor3Groups(int j, int i, Object[] columnDatas, Object[] vals, SeriesData coldata1,
			BufferedWriter bw2) throws Exception {
		if (j == 0) {
			handleTreeWrite(columnDatas, vals, coldata1, bw2, i, j);

		} else if (j == 1) {
			if (!vals[i].toString().equalsIgnoreCase("null")) {
				handleTreeWrite(columnDatas, vals, coldata1, bw2, i, j);
			}
		} else if (j == 2) {
			if (!vals[i].toString().equalsIgnoreCase("null")) {
				bw2.write(vals[i].toString() + ";");
			}
		} else {
			if (vals[i].toString().equalsIgnoreCase("NaN")) {
				bw2.write("0;");
			} else {
				bw2.write(vals[i].toString() + ";");
			}
		}
	}

	private void handleTreeWrite(Object[] columnDatas, Object[] vals, SeriesData coldata1, BufferedWriter bw2, int i,
			int j) throws IOException {
		coldata1 = (SeriesData) columnDatas[j + 1];

		Object[] vals1 = coldata1.getStringArray().getValuesList().toArray();

		if (vals1[i].toString().equalsIgnoreCase("null")) {
			bw2.write(vals[i].toString() + ";");
		} else {
			bw2.write(vals[i].toString() + ">>");
		}
	}

	private void putHeader(BufferedWriter bw2, String portfolio, String benchmark, String reportName,
			String reportPeriod, String startdate, String enddate) throws Exception {

		String actualBenchmark;

		if (benchmark.contains("BENCH:")) {
			actualBenchmark = benchmark.split("BENCH:")[1];
		} else {
			actualBenchmark = benchmark.split("CLIENT:/LA_PROD/")[1];
			actualBenchmark = actualBenchmark.split(".ACCT")[0];

		}

		bw2.write(portfolio + " vs. " + actualBenchmark + ";;;;;;;;;;;;;;;;");
		bw2.newLine();
		bw2.write(reportName);
		bw2.newLine();
		bw2.write(reportPeriod);
		bw2.newLine();
		bw2.write(";;;;;;;;;;;;;;;;");
		bw2.newLine();
		bw2.write(";;;;;;;;;;;;;;;;");
		bw2.newLine();
		bw2.write(putDateString(startdate));
		bw2.write(" to ");
		bw2.write(putDateString(enddate));
		bw2.write(";;;;;;;;;;;;;;;;;");
		bw2.newLine();
		bw2.write(";;;;;;;;;;;;;;;;");
		bw2.newLine();
		bw2.write(";;;;;;;;;;;;;;;;");
		bw2.newLine();

	}

	@SuppressWarnings("deprecation")
	private boolean determineGroupLevels(
			ApiResponse<com.factset.protobuf.stach.PackageProto.Package> calculationResultResponse) {
		boolean threeGroups = false;
		List<SeriesDefinition> columnList = calculationResultResponse.getData().getTables().entrySet().stream()
				.findFirst().get().getValue().getDefinition().getColumnsList();

		for (SeriesDefinition columnDef : columnList) {
			if (columnDef.getName().equals("group2")) {
				threeGroups = true;
			}
		}
		return threeGroups;
	}

	@SuppressWarnings("deprecation")
	private boolean determineNoGroup(
			ApiResponse<com.factset.protobuf.stach.PackageProto.Package> calculationResultResponse) {
		boolean noGroups = false;
		List<SeriesDefinition> columnList = calculationResultResponse.getData().getTables().entrySet().stream()
				.findFirst().get().getValue().getDefinition().getColumnsList();

		for (SeriesDefinition columnDef : columnList) {
			if (columnDef.getName().equals("group2") || columnDef.getName().equals("group1")) {
				noGroups = false;
				return noGroups;
			}
		}
		noGroups = true;
		return noGroups;
	}

	protected String putDateString(String date) throws Exception {
		DateFormat df = new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH);
		Date result = df.parse(date);

		DateFormat df2 = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
		String datout = df2.format(result);

		return datout;
	}

	private static ApiClient apiClientFactory() {
		if (apiClient != null) {
			return apiClient;
		}

		apiClient = new ApiClient();
		// apiClient.setBasePath("https://api.factset.com");
		apiClient.setBasePath("https://api.factset.com");
		apiClient.setUsername("LORD_ABBETT-906841"); // username-serial combination

		apiClient.setPassword("XP0KRNDlc4fnDsPqse7RRbhhflFBo4b39U7T5jz2"); // api key
		apiClient.setVerifyingSsl(false);

		return apiClient;
	}

	public Map<String, Object> loadRepDefIds() throws Exception {
		int repid;
		Map<String, Object> repDefIDS = new ConcurrentHashMap<String, Object>();
		String getRepDefSql = "";
		ResultLite repdef;

		Map<String, Object> params = new ConcurrentHashMap<String, Object>();
		getRepDefSql = "Select report_definition_id from reporting.dbo.report_definition where Name = :Name";

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution By Country of Risk");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Country_of_Risk.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Country_of_R.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Country_of_.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Country_of_R.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Country_of_R.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Country_of_.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution By Security Type and Issuer");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Issuers_(asset_t.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Issuers_(ass.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Issuers_(as.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Issuers_(ass.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Issuers_(ass.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Issuers_(as.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution By Issuer");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Issuers.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Issuers.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Issuers.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Issuers.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Issuers.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Issuers.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution By Ratings");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Ratings.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Ratings.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Ratings.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Ratings.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Ratings.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Ratings.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution By Security Type and Ratings");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Ratings_(asset_t.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Ratings_(ass.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Ratings_(as.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Ratings_(ass.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Ratings_(ass.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Ratings_(as.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution by Sector");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Sectors.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Sectors.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Sectors.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Sectors.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Sectors.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Sectors.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution By Security Type and Sector");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Sectors_(asset_t.txt".toLowerCase(), repid);
		repDefIDS.put("Attribution_by_Sectors(asset_ty.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Sectors_(ass.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Sectors(asse.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Sectors_(as.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Sectors(ass.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Sectors_(ass.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Sectors(asse.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Sectors_(ass.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Sectors(asse.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Sectors_(as.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Sectors(ass.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution By Security Type and Seniority");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Seniority_(asset.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Seniority_(a.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Seniority_(.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Seniority_(a.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Seniority_(a.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Seniority_(.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution by Analyst Name and Sector");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Analyst.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Analyst.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Analyst.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Analyst.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Analyst.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Analyst.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution by Currency");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Currency.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Currency.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Currency.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Currency.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Currency.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Currency.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution by Developed EM Mar");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Developed_EM_Mar.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Developed_EM.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Developed_EM.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Developed_EM.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Developed_E.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Developed_E.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution by Fixed Income Attribution");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Fixed_Income_Attribution.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Fixed_Income_Attribution.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Fixed_Income_Attribution.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Fixed_Income_Attribution.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Fixed_Income_Attribution.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Fixed_Income_Attribution.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution by Sector and Ratings");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Attribution_by_Sectors(ratings).txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Attribution_by_Sectors(rati.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Attribution_by_Sectors(rati.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Attribution_by_Sectors(rati.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Attribution_by_Sectors(rat.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Attribution_by_Sectors(rat.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet Best Worst Performers");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Best_Worst_performers.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Best_Worst_Performers.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Best_Worst_Performers.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Best_Worst_Performers.txt".toLowerCase(), repid);
		repDefIDS.put("WKLY_Best_Worst_Performers.txt".toLowerCase(), repid);
		repDefIDS.put("MNTH_Best_Worst_Performers.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet Characteristics Report");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Characteristics.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution by Currency-Region-Country-Sector");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Currency-Region-Country-Sector.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Currency-Region-Country-Sec.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Currency-Region-Country-Sec.txt".toLowerCase(), repid);
		repDefIDS.put("WTD_Currency-Region-Country-Sec.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Currency-Region-Country-Sec.txt".toLowerCase(), repid);
		repDefIDS.put("SI_Currency-Region-Country-Sect.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution by Region-Country-IG HY-Sector");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Region-Country-IG_HY-Sector.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Region-Country-IG_HY-Sector.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Region-Country-IG_HY-Sector.txt".toLowerCase(), repid);
		repDefIDS.put("WTD_Region-Country-IG_HY-Sector.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Region-Country-IG_HY-Sector.txt".toLowerCase(), repid);
		repDefIDS.put("SI_Region-Country-IG_HY-Sector.txt".toLowerCase(), repid);

		params.clear();
		params.put("Name", "FactSet 2 Factor Brinson Attribution by Region-IG HY-Country-Issuer");
		repdef = (ResultLite) baseDAO.findUsingSQL(idaJdbcTemplate, params, getRepDefSql, null, true);
		repid = (int) ((Integer) repdef.getData().get(0).get(0)).intValue();
		repDefIDS.put("Region-IG_HY-Country-Issuer.txt".toLowerCase(), repid);
		repDefIDS.put("MTD_Region-IG_HY-Country-Issuer.txt".toLowerCase(), repid);
		repDefIDS.put("QTD_Region-IG_HY-Country-Issuer.txt".toLowerCase(), repid);
		repDefIDS.put("WTD_Region-IG_HY-Country-Issuer.txt".toLowerCase(), repid);
		repDefIDS.put("YTD_Region-IG_HY-Country-Issuer.txt".toLowerCase(), repid);
		repDefIDS.put("SI_Region-IG_HY-Country-Issuer.txt".toLowerCase(), repid);

		return repDefIDS;

	}

}
